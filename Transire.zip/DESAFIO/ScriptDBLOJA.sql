CREATE TABLE T007_TIPO_COLABORADOR (
  T007ID_TIPO_COLABORADOR INT  NOT NULL   IDENTITY ,
  T007DS_TIPO_COLABORADOR VARCHAR(30)      ,
PRIMARY KEY(T007ID_TIPO_COLABORADOR));
GO




CREATE TABLE T005_STATUS_PRODUTO (
  T005ID_STATUS_PRODUTO INT  NOT NULL   IDENTITY ,
  T005DS_STATUS_PRODUTO VARCHAR(30)    ,
  T005FG_CLASS VARCHAR(50)      ,
PRIMARY KEY(T005ID_STATUS_PRODUTO));
GO




CREATE TABLE T003_TIPO_PRODUTO (
  T003ID_TIPO_PRODUTO INT  NOT NULL   IDENTITY ,
  T003DS_TIPO_PRODUTO VARCHAR(30)      ,
PRIMARY KEY(T003ID_TIPO_PRODUTO));
GO




CREATE TABLE T001_LOJA (
  T001ID_LOJA INT  NOT NULL   IDENTITY ,
  T001DS_LOJA VARCHAR(30)    ,
  T001DT_CADASTRO DATETIME      ,
PRIMARY KEY(T001ID_LOJA));
GO




CREATE TABLE T011_UNIDADE_MEDIDA (
  T011ID_UNIDADE_MEDIDA INT  NOT NULL   IDENTITY ,
  T011DS_UNIDADE_MEDIDA VARCHAR(50)      ,
PRIMARY KEY(T011ID_UNIDADE_MEDIDA));
GO

CREATE TABLE T006_COLABORADOR (
  T006ID_COLABORADOR INT  NOT NULL   IDENTITY ,
  T007ID_TIPO_COLABORADOR INT  NOT NULL  ,
  T006NM_COLABORADOR VARCHAR(50)    ,
  T006DS_ENDERECO VARCHAR(50)    ,
  T006NM_CIDADE VARCHAR(50)    ,
  T006NM_UF VARCHAR(2)    ,
  T006NR_CNPJ_CPF VARCHAR(20)    ,
  T006NR_TELEFONE VARCHAR(20)      ,
PRIMARY KEY(T006ID_COLABORADOR),
  FOREIGN KEY(T007ID_TIPO_COLABORADOR)
    REFERENCES T007_TIPO_COLABORADOR(T007ID_TIPO_COLABORADOR));
GO

CREATE INDEX IFK_Rel_05 ON T006_COLABORADOR (T007ID_TIPO_COLABORADOR);
GO

CREATE TABLE T002_PRODUTO (
  T002ID_PRODUTO INT  NOT NULL   IDENTITY ,
  T006ID_FORNECEDOR INT  NOT NULL  ,
  T005ID_STATUS_PRODUTO INT  NOT NULL  ,
  T003ID_TIPO_PRODUTO INT  NOT NULL  ,
  T011ID_UNIDADE_MEDIDA INT  NOT NULL  ,
  T002DS_PRODUTO VARCHAR(50)    ,
  T002VL_PRECO_UNITARIO NUMERIC(18,4)    ,
  T002QT_ESTOQUE NUMERIC(18,4)    ,
  T002DT_CADASTRO DATETIME      ,
PRIMARY KEY(T002ID_PRODUTO),
  FOREIGN KEY(T003ID_TIPO_PRODUTO)
    REFERENCES T003_TIPO_PRODUTO(T003ID_TIPO_PRODUTO),
  FOREIGN KEY(T005ID_STATUS_PRODUTO)
    REFERENCES T005_STATUS_PRODUTO(T005ID_STATUS_PRODUTO),
  FOREIGN KEY(T006ID_FORNECEDOR)
    REFERENCES T006_COLABORADOR(T006ID_COLABORADOR),
  FOREIGN KEY(T011ID_UNIDADE_MEDIDA)
    REFERENCES T011_UNIDADE_MEDIDA(T011ID_UNIDADE_MEDIDA));
GO


CREATE INDEX IFK_Rel_01 ON T002_PRODUTO (T003ID_TIPO_PRODUTO);
GO
CREATE INDEX IFK_Rel_04 ON T002_PRODUTO (T005ID_STATUS_PRODUTO);
GO
CREATE INDEX IFK_Rel_06 ON T002_PRODUTO (T006ID_FORNECEDOR);
GO
CREATE INDEX IFK_Rel_12 ON T002_PRODUTO (T011ID_UNIDADE_MEDIDA);
GO


CREATE TABLE T008_PEDIDO (
  T008ID_PEDIDO INT  NOT NULL   IDENTITY ,
  T006ID_VENDEDOR INT  NOT NULL  ,
  T00DT_PEDIDO DATETIME      ,
PRIMARY KEY(T008ID_PEDIDO),
  FOREIGN KEY(T006ID_VENDEDOR)
    REFERENCES T006_COLABORADOR(T006ID_COLABORADOR));
GO


CREATE INDEX IFK_Rel_10 ON T008_PEDIDO (T006ID_VENDEDOR);
GO


CREATE TABLE T009_ITEM (
  T009ID_ITEM INT  NOT NULL   IDENTITY ,
  T002ID_PRODUTO INT  NOT NULL  ,
  T009QT_PEDIDO NUMERIC(18,4)    ,
  T009VL_PEDIDO NUMERIC(18,4)      ,
PRIMARY KEY(T009ID_ITEM),
  FOREIGN KEY(T002ID_PRODUTO)
    REFERENCES T002_PRODUTO(T002ID_PRODUTO));
GO


CREATE INDEX IFK_Rel_11 ON T009_ITEM (T002ID_PRODUTO);
GO


CREATE TABLE T012_CLIENTE_PEDIDO (
  T008ID_PEDIDO INT  NOT NULL  ,
  T006ID_CLIENTE INT  NOT NULL    ,
PRIMARY KEY(T008ID_PEDIDO, T006ID_CLIENTE),
  FOREIGN KEY(T006ID_CLIENTE)
    REFERENCES T006_COLABORADOR(T006ID_COLABORADOR),
  FOREIGN KEY(T008ID_PEDIDO)
    REFERENCES T008_PEDIDO(T008ID_PEDIDO));
GO


CREATE INDEX IFK_Rel_13 ON T012_CLIENTE_PEDIDO (T006ID_CLIENTE);
GO
CREATE INDEX IFK_Rel_14 ON T012_CLIENTE_PEDIDO (T008ID_PEDIDO);
GO


CREATE TABLE T010_PEDIDO_ITEM (
  T008ID_PEDIDO INT  NOT NULL  ,
  T009ID_ITEM INT  NOT NULL    ,
PRIMARY KEY(T008ID_PEDIDO, T009ID_ITEM),
  FOREIGN KEY(T008ID_PEDIDO)
    REFERENCES T008_PEDIDO(T008ID_PEDIDO),
  FOREIGN KEY(T009ID_ITEM)
    REFERENCES T009_ITEM(T009ID_ITEM));
GO


CREATE INDEX IFK_Rel_08 ON T010_PEDIDO_ITEM (T008ID_PEDIDO);
GO
CREATE INDEX IFK_Rel_09 ON T010_PEDIDO_ITEM (T009ID_ITEM);
GO


CREATE TABLE T004_LOJA_PRODUTO (
  T001ID_LOJA INT  NOT NULL  ,
  T002ID_PRODUTO INT  NOT NULL    ,
PRIMARY KEY(T001ID_LOJA, T002ID_PRODUTO),
  FOREIGN KEY(T001ID_LOJA)
    REFERENCES T001_LOJA(T001ID_LOJA),
  FOREIGN KEY(T002ID_PRODUTO)
    REFERENCES T002_PRODUTO(T002ID_PRODUTO));
GO

CREATE INDEX IFK_Rel_02 ON T004_LOJA_PRODUTO (T001ID_LOJA);
GO
CREATE INDEX IFK_Rel_03 ON T004_LOJA_PRODUTO (T002ID_PRODUTO);
GO

--------------------------------------------------------------
Insert Into T001_LOJA Values('Variety Store', GETDATE())


Insert Into T011_UNIDADE_MEDIDA Values('UN')
Insert Into T011_UNIDADE_MEDIDA Values('PC')
Insert Into T011_UNIDADE_MEDIDA Values('KG')
Insert Into T011_UNIDADE_MEDIDA Values('CX')
--------------------------------------------------------------
Insert Into T003_TIPO_PRODUTO Values('LIMPESA')
Insert Into T003_TIPO_PRODUTO Values('MÉDICO')
Insert Into T003_TIPO_PRODUTO Values('BENS DE CONSUMO')
Insert Into T003_TIPO_PRODUTO Values('VESTUARIO')
Insert Into T003_TIPO_PRODUTO Values('MATERIAL DE CONSTRUÇÃO')
Insert Into T003_TIPO_PRODUTO Values('OUTROS')
--------------------------------------------------------------
Insert Into T007_TIPO_COLABORADOR Values('FORNECEDOR')
Insert Into T007_TIPO_COLABORADOR Values('CLIENTE')
Insert Into T007_TIPO_COLABORADOR Values('VENDEDOR')

--------------------------------------------------------------
Insert Into T005_STATUS_PRODUTO Values ('ATIVO','label label-success')
Insert Into T005_STATUS_PRODUTO Values ('DELETADO','label label-success')
Insert Into T005_STATUS_PRODUTO Values ('NÍVEL ALTO','label label-success')
Insert Into T005_STATUS_PRODUTO Values ('NÍVEL MÉDIO','label label-warning')
Insert Into T005_STATUS_PRODUTO Values ('NÍVEL BAIXO','label label-danger')

Insert Into T006_COLABORADOR Values (1,'FORNECEDOR 01','Rua 01','MANAUS','AM','14.381.510/0001-60','(092)1111-1111')
Insert Into T006_COLABORADOR Values (1,'FORNECEDOR 02','Rua 02','MANAUS','AM','38.432.854/0001-10','(092)2222-2222')
Insert Into T006_COLABORADOR Values (1,'FORNECEDOR 03','Rua 03','MANAUS','AM','01.205.677/0001-29','(092)3333-3333')
Insert Into T006_COLABORADOR Values (1,'FORNECEDOR 04','Rua 04','MANAUS','AM','73.260.365/0001-29','(092)4444-4444')
Insert Into T006_COLABORADOR Values (1,'CLIENTE 01','Rua 01','MANAUS','AM','33.532.724/0001-35','(092)1111-1111')
Insert Into T006_COLABORADOR Values (1,'CLIENTE 02','Rua 02','MANAUS','AM','12.152.403/0001-35','(092)2222-2222')
Insert Into T006_COLABORADOR Values (1,'CLIENTE 03','Rua 03','MANAUS','AM','72.127.946/0001-24','(092)3333-3333')
Insert Into T006_COLABORADOR Values (1,'CLIENTE 04','Rua 04','MANAUS','AM','73.165.107/0001-63','(092)4444-4444')
Insert Into T006_COLABORADOR Values (1,'VENDEDOR 01','Rua 01','MANAUS','AM','836.914.538.91','(092)1111-1111')
Insert Into T006_COLABORADOR Values (1,'VENDEDOR 02','Rua 02','MANAUS','AM','964.274.450.30','(092)2222-2222')
Insert Into T006_COLABORADOR Values (1,'VENDEDOR 03','Rua 03','MANAUS','AM','766.023.266.51','(092)3333-3333')
Insert Into T006_COLABORADOR Values (1,'VENDEDOR 04','Rua 04','MANAUS','AM','248.439.756.99','(092)4444-4444')

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
Insert Into T002_PRODUTO Values(1,1,1,1,'Agulha ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Álcool combustível ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Almofadas ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Aparador (sala) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Apito ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Armário de madeira ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Árvore de Natal ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Balão de borracha (bexiga) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Bandeira (de pano) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Bicicleta ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Bola de futebol ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Bolsa térmica ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Brinquedos ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Bronzeador ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Buquê (flores) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Buzina (automóvel) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Buzina a gás ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Cadeira de praia ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Cadeira de madeira ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Caixas de som amplificadas ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Cama de madeira ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Carrilhão com estante ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Cartão de Páscoa ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Casa popular ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Charuto ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Cigarro ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Cinto de couro ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Coelho de pelúcia ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Confete / Serpentina ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Convite (impresso) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Cruz de madeira ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Diesel ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Ducha higiênica ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Enfeites ár',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'vore Natal ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Ferro de passar ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Filtro de papel ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Fita ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Fogos de artifício ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Fósforos ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Gás de cozinha ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Gasolina ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Grama ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Guarda-sol ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Imagem de santo ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Joelheira ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Jogos de videogame ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Jornal ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Lareira ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Lembrancinha (souvenir) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Livros ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Luva ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Lubrificantes ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Luminária ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Malas ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Malha ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Máscara de lantejoulas ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Máscara de plástico ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Medalha de metal ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Mesa de madeira ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Papel alumínio ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Papel celofane ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Papel pardo ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Papel sulfite ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Pastas em geral ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Patins ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Peneira de couro ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Pincel ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Pinhão ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Plantas (pomar) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Presépio - Natal ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Preservativo ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Protetor solar ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Quadro de parede ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Querosene para aviação ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Rações para gato e cão ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Regador ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Revistas ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Sela ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Spray espuma ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Sofá ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Terço de plástico ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Tinta plástica ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Vela ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Urna funerária ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Utensílios de jardim ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Vaso de plantas ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Vassoura ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Água de colônia (nacional) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Arranjo de cabelo ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Batom ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Biquíni ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(2,1,1,1,'Biquíni com lantejoulas ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Bolsa (geral) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Bolsa de couro ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Bota ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Cachecol ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Calça (tecido) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Calça de couro ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Calça jeans ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Camisa ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Camisa xadrez ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Casaco de pele Vison ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Chapéu de couro ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Chapéu de palha ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Chinelo ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Colar havaiano ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Fantasia - roupa com arame ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Fantasia - roupa tecido ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Fivela ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Gibão de Couro ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Jóias ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Óculos de sol ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Perfume importado ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Perfume nacional ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Roupas ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Sapatos ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Tênis importado ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Traje de noivo ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Vestido ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Vestido da noiva ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Adoçante ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Achocolatado ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Açúcar ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Amendoim ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Arroz ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Bacalhau importado ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Batata ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Biscoito ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Bolo de brigadeiro ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Bombons ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Cachorro-quente ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Camarão ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Canjica ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Carne bovina ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Catchup ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Cebola ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Cereal em lata ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Chocolate ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Cocada ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Colomba pascal chocolate ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Ervilhas ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Farinha de trigo ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(3,1,1,1,'Feijão ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Fermento ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Fondue de chocolate ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Fondue de queijo ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Frango ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Frutas ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Fubá ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Gelatina ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Iogurte ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Leite ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Leite em pó ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Lentilha ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Maionese ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Maisena',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Refresco em pó ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Sal ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Sopa de pacotinho ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Sorvete de massa ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Sorvete picolé ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Tomate ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Vinagre ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Absorvente higiênico ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Água sanitária ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Álcool (material de limpeza) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Algodão de limpeza ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Amaciante ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Band-aid (curativo) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Condicionadores (banho) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Cotonetes ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Desinfetante ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Detergente ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Desodorantes ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Escova de dentes ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Esparadrapo ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Esponja de aço (pacote com ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Fralda descartável ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Gaze ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Papel higiênico (com ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Pasta de dentes ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Sabão em barra ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Sabão em pó ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Sabonete ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Saponáceo ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Shampoo ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Agenda escolar ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Apontador ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Borracha ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Caderno universitário ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Caneta ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Cola tenaz ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Estojos para lápis ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Fichário ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Folhas para fichário ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Lancheiras ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Lápis ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Mochilas ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Pastas plásticas ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(4,1,1,1,'Régua ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Tinta guache ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Água ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Água de coco ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Água mineral ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Cachaça ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Café ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Caipirinha ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Cerveja (lata) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Cerveja (garrafa) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Champagne ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Refrigerante (lata) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Refrigerante (garrafa) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Suco pronto ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Wisky ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Vinho ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Copos ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Garrafa térmica ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Pratos (cozinha) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Panelas ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Taças ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Talheres ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Cobertor ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Colchão ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Edredom ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Lençol ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Toalha de banho ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Toalha de mesa ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Travesseiro ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Aparelho de barbear ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Aparelho de som ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Aparelho MP',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Batedeira ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'CD (compact disk) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Computador acima de R$ ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Computador até R$ ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'DVD (aparelho) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'DVD (cartucho) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Fogão ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Geladeira ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Liquidificador ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Microfones ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Micro-ondas (forno) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Notebook acima de R$ ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Telefone celular ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Telefonia ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Televisor ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Torradeira elétrica ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Ventilador ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Cimento ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Telha ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Tijolo (milheiro) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Tinta ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Veículo Celta ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Veículo Toyota Corolla ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Veículo Celta ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Veículo Toyota Corolla ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Aeronaves ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Barco ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Trator ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Moto (acima de 250 CC)',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Moto (até 125',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Academia ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Adestramento de cães ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Almoço em restaurante ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Buffet (jantar) - Restaurante ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Casamento no civil ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Consulta veterinária ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Consulta médica ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Conta de água ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Conta de luz ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Conta de telefone ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Conta de celular ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Decoração de igreja ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Dia de noiva (salão de beleza) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Energia elétrica ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Escola particular e curso de inglês ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Hospedagem em hotel ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Ingressos (tickets) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Juros bancários ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Hotel para animais ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Mensalidade do clube ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'ingresso e van - desfile carnaval ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Pacote lua de mel (viagem) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Passagem aérea ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Transporte rodoviário interestadual passageiros ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Transporte urbano passageiros metropolitano ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Serviço de TV por assinatura ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Teatro e cinema ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Universidade (mensalidade) ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Agogô ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Bandolim ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Banjo ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Bateria ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Bongô ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Bumbo ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Cavaquinho ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Clarineta ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Contrabaixo ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Corneta ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Cuíca ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Flauta transversal ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Gaita ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Guitarra ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Pandeiro ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Piano ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Prato ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Reco-reco ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Saxofone ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Sousafone ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Tamborim ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Teclado ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Triângulo ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Trombone ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Trompete ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Viola ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Violão ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Violino ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Violoncelo ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Abaixador de língua ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Aparelho de pressão digital ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Andador ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Avental médico ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Bisturi ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Cadeira de rodas ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Cateter ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Coletor de urina ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Comadre / Papagaio ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Desfibrilador ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Inalador ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Lâmina para microscópio ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Luva cirúrgica ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Maca ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Máscara cirúrgica ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Medicamento de uso animal ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Medicamentos de uso humano ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Medidor de glicose ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Mertiolate/ mercúrio ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Muleta ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Pipeta de laboratório ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Seringa ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Sonda aspiração traqueal ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Sonda uretral ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Soro ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Termômetro ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Tipóia ',0,0,GETDATE())
Insert Into T002_PRODUTO Values(1,1,1,1,'Xarope para tosse ',0,0,GETDATE())