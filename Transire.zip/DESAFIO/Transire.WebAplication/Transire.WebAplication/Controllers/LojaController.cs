﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Transire.WebAplication.Models;
namespace Transire.WebAplication.Controllers
{
	public class LojaController : Controller
	{
		public ActionResult LojaCadastrar()
		{
						return PartialView();
		}
		public ActionResult LojaAlterar()
		{
			LojaModel objLoja = new LojaModel();
			objLoja.IdLoja = Int32.Parse(Request.QueryString["id"].ToString());
			List<LojaModel> listLoja =  objLoja.Consultar();
						ViewBag.txtDsLoja = listLoja[0].DsLoja.ToString();
			ViewBag.txtDtCadastro = listLoja[0].DtCadastro.ToString();
			ViewBag.IdLoja = listLoja[0].IdLoja.ToString();
			return PartialView();
		}
		[HttpPost]
		public void LojaSalvar()
		{
			LojaModel objLoja = new LojaModel();
						objLoja.DsLoja = Request["txtDsLoja"].ToString();
			objLoja.DtCadastro = DateTime.Parse(Request["txtDtCadastro"].ToString());
			string _response = objLoja.Inserir();
			if (_response.Split('|')[0].Equals("sucesso"))
			{
			}
			else
			{
			}
			Response.Write(_response);
		}
		[HttpPost]
		public void LojaAtualizar()
		{
			LojaModel objLoja = new LojaModel();
						objLoja.DsLoja = Request["txtDsLoja"].ToString();
			objLoja.DtCadastro = DateTime.Parse(Request["txtDtCadastro"].ToString());
			objLoja.IdLoja = Int32.Parse(Request["IdLoja"].ToString());
			Response.Write(objLoja.Alterar());
		}
		[HttpGet]
		public void LojaExcluir()
		{
			LojaModel objLoja = new LojaModel();
						objLoja.DsLoja = "";
			objLoja.DtCadastro = DateTime.Parse("01/01/9999");
			objLoja.IdLoja = 0;//Int32.Parse(Request.QueryString["id"].ToString());
			Response.Write(objLoja.Excluir());
		}
		public ActionResult LojaListar()
		{
			return PartialView();
		}
		public ActionResult ExibirDataTable(JQueryDataTablesParamViewModel Params)
		{
			LojaModel objLoja = new LojaModel();
			objLoja.DsLoja = "";
			objLoja.DtCadastro = DateTime.Parse("01/01/9999");
			objLoja.IdLoja = 0;//Int32.Parse(Request.QueryString["id"].ToString());
			int ChaveDados = 0;
			int TotalRegistro = 0;
			int TotalRegistrosFiltrados = 0;//Convert.ToInt32(Request.Params["total"]);
			IEnumerable<LojaModel> filteredLoja = objLoja.Exibir(ChaveDados, Params, out TotalRegistro, out TotalRegistrosFiltrados);
			var isIdentificadorSortable = Convert.ToBoolean(Request["bSortable_1"]);
			var isDsLojaSortable = Convert.ToBoolean(Request["bSortable_2"]);
			var isDtCadastroSortable = Convert.ToBoolean(Request["bSortable_3"]);
			var sortColumnIndex = Convert.ToInt32(Request["iSortCol_0"]);
			Func<LojaModel, string> orderingLoja = (c => sortColumnIndex == 1 && isIdentificadorSortable ? c.IdLoja.ToString() :
															sortColumnIndex == 2 && isDsLojaSortable ? c.DsLoja.ToString() :
															sortColumnIndex == 3 && isDtCadastroSortable ? c.DtCadastro.ToString() :
															"");
			var sortDirection = Request["sSortDir_0"]; // asc or desc
			if (sortDirection == "asc")
				filteredLoja = filteredLoja.OrderBy(orderingLoja);
			else
				filteredLoja = filteredLoja.OrderByDescending(orderingLoja);
			var result = from c in filteredLoja select new[] { "", Convert.ToString(c.IdLoja) , c.DsLoja, Convert.ToString(c.DtCadastro) };
			return Json(new
			{
				sEcho = Params.sEcho,
				iTotalRecords = TotalRegistro,
				iTotalDisplayRecords = TotalRegistrosFiltrados,
				aaData = result
				}, JsonRequestBehavior.AllowGet);
		}
	}
}

