﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Transire.WebAplication.Models;
namespace Transire.WebAplication.Controllers
{
	public class ProdutoController : Controller
	{
		public ActionResult ProdutoCadastrar()
		{
			ViewBag.listNmColaborador = new SelectList(new ColaboradorModel().Consultar(), "IdColaborador","NmColaborador");
			ViewBag.listDsStatusProduto = new SelectList(new StatusProdutoModel().Consultar(), "IdStatusProduto","DsStatusProduto");
			ViewBag.listDsTipoProduto = new SelectList(new TipoProdutoModel().Consultar(), "IdTipoProduto","DsTipoProduto");
			ViewBag.listDsUnidadeMedida = new SelectList(new UnidadeMedidaModel().Consultar(), "IdUnidadeMedida","DsUnidadeMedida");
			return PartialView();
		}
		public ActionResult ProdutoAlterar()
		{
			ProdutoModel objProduto = new ProdutoModel();
			objProduto.IdProduto = Int32.Parse(Request.QueryString["id"].ToString());
			List<ProdutoModel> listProduto =  objProduto.Consultar();
			ViewBag.listNmColaborador = new SelectList(new ColaboradorModel().Consultar(), "IdColaborador","NmColaborador", listProduto[0].objColaborador.IdColaborador);
			ViewBag.listDsStatusProduto = new SelectList(new StatusProdutoModel().Consultar(), "IdStatusProduto","DsStatusProduto", listProduto[0].objStatusProduto.IdStatusProduto);
			ViewBag.listDsTipoProduto = new SelectList(new TipoProdutoModel().Consultar(), "IdTipoProduto","DsTipoProduto", listProduto[0].objTipoProduto.IdTipoProduto);
			ViewBag.listDsUnidadeMedida = new SelectList(new UnidadeMedidaModel().Consultar(), "IdUnidadeMedida","DsUnidadeMedida", listProduto[0].objUnidadeMedida.IdUnidadeMedida);
			ViewBag.txtDsProduto = listProduto[0].DsProduto.ToString();
			ViewBag.txtVlPrecoUnitario = listProduto[0].VlPrecoUnitario.ToString();
			ViewBag.txtQtEstoque = listProduto[0].QtEstoque.ToString();
			ViewBag.txtDtCadastro = listProduto[0].DtCadastro.ToString();
			ViewBag.IdProduto = listProduto[0].IdProduto.ToString();
			return PartialView();
		}
		[HttpPost]
		public void ProdutoSalvar()
		{
			ProdutoModel objProduto = new ProdutoModel();
			objProduto.objColaborador.IdColaborador = Int32.Parse(Request["cboNmColaborador"].ToString());//IdFornecedor
			objProduto.objStatusProduto.IdStatusProduto = Int32.Parse(Request["cboDsStatusProduto"].ToString());
			objProduto.objTipoProduto.IdTipoProduto = Int32.Parse(Request["cboDsTipoProduto"].ToString());
			objProduto.objUnidadeMedida.IdUnidadeMedida = Int32.Parse(Request["cboDsUnidadeMedida"].ToString());
			objProduto.DsProduto = Request["txtDsProduto"].ToString();
			objProduto.VlPrecoUnitario = decimal.Parse(Request["txtVlPrecoUnitario"].ToString().Replace(".", ","));
			objProduto.QtEstoque = decimal.Parse(Request["txtQtEstoque"].ToString().Replace(".", ","));
			objProduto.DtCadastro = DateTime.Parse(Request["txtDtCadastro"].ToString());
			string _response = objProduto.Inserir();
			if (_response.Split('|')[0].Equals("sucesso"))
			{
			}
			else
			{
			}
			Response.Write(_response);
		}
		[HttpPost]
		public void ProdutoAtualizar()
		{
			ProdutoModel objProduto = new ProdutoModel();
			objProduto.objColaborador.IdColaborador = Int32.Parse(Request["cboNmColaborador"].ToString());//IdFornecedor
			objProduto.objStatusProduto.IdStatusProduto = Int32.Parse(Request["cboDsStatusProduto"].ToString());
			objProduto.objTipoProduto.IdTipoProduto = Int32.Parse(Request["cboDsTipoProduto"].ToString());
			objProduto.objUnidadeMedida.IdUnidadeMedida = Int32.Parse(Request["cboDsUnidadeMedida"].ToString());
			objProduto.DsProduto = Request["txtDsProduto"].ToString();
			objProduto.VlPrecoUnitario = decimal.Parse(Request["txtVlPrecoUnitario"].ToString().Replace(".", ","));
			objProduto.QtEstoque = decimal.Parse(Request["txtQtEstoque"].ToString().Replace(".", ","));
			objProduto.DtCadastro = DateTime.Parse(Request["txtDtCadastro"].ToString());
			objProduto.IdProduto = Int32.Parse(Request["IdProduto"].ToString());
			Response.Write(objProduto.Alterar());
		}
		[HttpGet]
		public void ProdutoExcluir()
		{
			ProdutoModel objProduto = new ProdutoModel();
			objProduto.objColaborador.IdColaborador =  0;//IdFornecedor
			objProduto.objStatusProduto.IdStatusProduto =  0;
			objProduto.objTipoProduto.IdTipoProduto =  0;
			objProduto.objUnidadeMedida.IdUnidadeMedida =  0;
			objProduto.DsProduto = "";
			objProduto.VlPrecoUnitario = 0;
			objProduto.QtEstoque = 0;
			objProduto.DtCadastro = DateTime.Parse("01/01/9999");
			objProduto.IdProduto = 0;//Int32.Parse(Request.QueryString["id"].ToString());
			Response.Write(objProduto.Excluir());
		}
		public ActionResult ProdutoListar()
		{
			return PartialView();
		}
		public ActionResult ExibirDataTable(JQueryDataTablesParamViewModel Params)
		{
			ProdutoModel objProduto = new ProdutoModel();
			objProduto.objColaborador.IdColaborador =  0;//IdFornecedor
			objProduto.objStatusProduto.IdStatusProduto =  0;
			objProduto.objTipoProduto.IdTipoProduto =  0;
			objProduto.objUnidadeMedida.IdUnidadeMedida =  0;
			objProduto.DsProduto = "";
			objProduto.VlPrecoUnitario = 0;
			objProduto.QtEstoque = 0;
			objProduto.DtCadastro = DateTime.Parse("01/01/9999");
			objProduto.IdProduto = 0;//Int32.Parse(Request.QueryString["id"].ToString());
			int ChaveDados = 0;
			int TotalRegistro = 0;
			int TotalRegistrosFiltrados = 0;//Convert.ToInt32(Request.Params["total"]);
			IEnumerable<ProdutoModel> filteredProduto = objProduto.Exibir(ChaveDados, Params, out TotalRegistro, out TotalRegistrosFiltrados);
			var isIdentificadorSortable = Convert.ToBoolean(Request["bSortable_1"]);
			var isNmColaboradorSortable = Convert.ToBoolean(Request["bSortable_2"]);
			var isDsStatusProdutoSortable = Convert.ToBoolean(Request["bSortable_3"]);
			var isDsTipoProdutoSortable = Convert.ToBoolean(Request["bSortable_4"]);
			var isDsUnidadeMedidaSortable = Convert.ToBoolean(Request["bSortable_5"]);
			var isDsProdutoSortable = Convert.ToBoolean(Request["bSortable_6"]);
			var isVlPrecoUnitarioSortable = Convert.ToBoolean(Request["bSortable_7"]);
			var isQtEstoqueSortable = Convert.ToBoolean(Request["bSortable_8"]);
			var isDtCadastroSortable = Convert.ToBoolean(Request["bSortable_9"]);
			var sortColumnIndex = Convert.ToInt32(Request["iSortCol_0"]);
			Func<ProdutoModel, string> orderingProduto = (c => sortColumnIndex == 1 && isIdentificadorSortable ? c.IdProduto.ToString() :
															sortColumnIndex == 2 && isNmColaboradorSortable ? c.objColaborador.NmColaborador :
															sortColumnIndex == 3 && isDsStatusProdutoSortable ? c.objStatusProduto.DsStatusProduto :
															sortColumnIndex == 4 && isDsTipoProdutoSortable ? c.objTipoProduto.DsTipoProduto :
															sortColumnIndex == 5 && isDsUnidadeMedidaSortable ? c.objUnidadeMedida.DsUnidadeMedida.ToString() :
															sortColumnIndex == 6 && isDsProdutoSortable ? c.DsProduto.ToString() :
															sortColumnIndex == 7 && isVlPrecoUnitarioSortable ? c.VlPrecoUnitario.ToString() :
															sortColumnIndex == 8 && isQtEstoqueSortable ? c.QtEstoque.ToString() :
															sortColumnIndex == 9 && isDtCadastroSortable ? c.DtCadastro.ToString() :
															"");
			var sortDirection = Request["sSortDir_0"]; // asc or desc
			if (sortDirection == "asc")
				filteredProduto = filteredProduto.OrderBy(orderingProduto);
			else
				filteredProduto = filteredProduto.OrderByDescending(orderingProduto);
			var result = from c in filteredProduto select new[] { ""
                                                                , Convert.ToString(c.IdProduto) 
                                                                , c.objColaborador.NmColaborador
                                                                , c.objStatusProduto.DsStatusProduto
                                                                , c.objTipoProduto.DsTipoProduto
                                                                , c.objUnidadeMedida.DsUnidadeMedida
                                                                , c.DsProduto, Convert.ToString(c.VlPrecoUnitario)
                                                                , Convert.ToString(c.QtEstoque)
                                                                , Convert.ToString(c.DtCadastro) };
			return Json(new
			{
				sEcho = Params.sEcho,
				iTotalRecords = TotalRegistro,
				iTotalDisplayRecords = TotalRegistrosFiltrados,
				aaData = result
				}, JsonRequestBehavior.AllowGet);
		}
	}
}

