﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Transire.WebAplication.Models;
namespace Transire.WebAplication.Controllers
{
	public class StatusProdutoController : Controller
	{
		public ActionResult StatusProdutoCadastrar()
		{
						return PartialView();
		}
		public ActionResult StatusProdutoAlterar()
		{
			StatusProdutoModel objStatusProduto = new StatusProdutoModel();
			objStatusProduto.IdStatusProduto = Int32.Parse(Request.QueryString["id"].ToString());
			List<StatusProdutoModel> listStatusProduto =  objStatusProduto.Consultar();
						ViewBag.txtDsStatusProduto = listStatusProduto[0].DsStatusProduto.ToString();
			ViewBag.txtFgClass = listStatusProduto[0].FgClass.ToString();
			ViewBag.IdStatusProduto = listStatusProduto[0].IdStatusProduto.ToString();
			return PartialView();
		}
		[HttpPost]
		public void StatusProdutoSalvar()
		{
			StatusProdutoModel objStatusProduto = new StatusProdutoModel();
						objStatusProduto.DsStatusProduto = Request["txtDsStatusProduto"].ToString();
			objStatusProduto.FgClass = Request["txtFgClass"].ToString();
			string _response = objStatusProduto.Inserir();
			if (_response.Split('|')[0].Equals("sucesso"))
			{
			}
			else
			{
			}
			Response.Write(_response);
		}
		[HttpPost]
		public void StatusProdutoAtualizar()
		{
			StatusProdutoModel objStatusProduto = new StatusProdutoModel();
						objStatusProduto.DsStatusProduto = Request["txtDsStatusProduto"].ToString();
			objStatusProduto.FgClass = Request["txtFgClass"].ToString();
			objStatusProduto.IdStatusProduto = Int32.Parse(Request["IdStatusProduto"].ToString());
			Response.Write(objStatusProduto.Alterar());
		}
		[HttpGet]
		public void StatusProdutoExcluir()
		{
			StatusProdutoModel objStatusProduto = new StatusProdutoModel();
						objStatusProduto.DsStatusProduto = "";
			objStatusProduto.FgClass = "";
			objStatusProduto.IdStatusProduto = 0;//Int32.Parse(Request.QueryString["id"].ToString());
			Response.Write(objStatusProduto.Excluir());
		}
		public ActionResult StatusProdutoListar()
		{
			return PartialView();
		}
		public ActionResult ExibirDataTable(JQueryDataTablesParamViewModel Params)
		{
			StatusProdutoModel objStatusProduto = new StatusProdutoModel();
			objStatusProduto.DsStatusProduto = "";
			objStatusProduto.FgClass = "";
			objStatusProduto.IdStatusProduto = 0;//Int32.Parse(Request.QueryString["id"].ToString());
			int ChaveDados = 0;
			int TotalRegistro = 0;
			int TotalRegistrosFiltrados = 0;//Convert.ToInt32(Request.Params["total"]);
			IEnumerable<StatusProdutoModel> filteredStatusProduto = objStatusProduto.Exibir(ChaveDados, Params, out TotalRegistro, out TotalRegistrosFiltrados);
			var isIdentificadorSortable = Convert.ToBoolean(Request["bSortable_1"]);
			var isDsStatusProdutoSortable = Convert.ToBoolean(Request["bSortable_2"]);
			var isFgClassSortable = Convert.ToBoolean(Request["bSortable_3"]);
			var sortColumnIndex = Convert.ToInt32(Request["iSortCol_0"]);
			Func<StatusProdutoModel, string> orderingStatusProduto = (c => sortColumnIndex == 1 && isIdentificadorSortable ? c.IdStatusProduto.ToString() :
															sortColumnIndex == 2 && isDsStatusProdutoSortable ? c.DsStatusProduto.ToString() :
															sortColumnIndex == 3 && isFgClassSortable ? c.FgClass.ToString() :
															"");
			var sortDirection = Request["sSortDir_0"]; // asc or desc
			if (sortDirection == "asc")
				filteredStatusProduto = filteredStatusProduto.OrderBy(orderingStatusProduto);
			else
				filteredStatusProduto = filteredStatusProduto.OrderByDescending(orderingStatusProduto);
			var result = from c in filteredStatusProduto select new[] { "", Convert.ToString(c.IdStatusProduto) , c.DsStatusProduto, c.FgClass };
			return Json(new
			{
				sEcho = Params.sEcho,
				iTotalRecords = TotalRegistro,
				iTotalDisplayRecords = TotalRegistrosFiltrados,
				aaData = result
				}, JsonRequestBehavior.AllowGet);
		}
	}
}

