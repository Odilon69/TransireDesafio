﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Transire.WebAplication.Models;
namespace Transire.WebAplication.Controllers
{
	public class TipoColaboradorController : Controller
	{
		public ActionResult TipoColaboradorCadastrar()
		{
						return PartialView();
		}
		public ActionResult TipoColaboradorAlterar()
		{
			TipoColaboradorModel objTipoColaborador = new TipoColaboradorModel();
			objTipoColaborador.IdTipoColaborador = Int32.Parse(Request.QueryString["id"].ToString());
			List<TipoColaboradorModel> listTipoColaborador =  objTipoColaborador.Consultar();
						ViewBag.txtDsTipoColaborador = listTipoColaborador[0].DsTipoColaborador.ToString();
			ViewBag.IdTipoColaborador = listTipoColaborador[0].IdTipoColaborador.ToString();
			return PartialView();
		}
		[HttpPost]
		public void TipoColaboradorSalvar()
		{
			TipoColaboradorModel objTipoColaborador = new TipoColaboradorModel();
						objTipoColaborador.DsTipoColaborador = Request["txtDsTipoColaborador"].ToString();
			string _response = objTipoColaborador.Inserir();
			if (_response.Split('|')[0].Equals("sucesso"))
			{
			}
			else
			{
			}
			Response.Write(_response);
		}
		[HttpPost]
		public void TipoColaboradorAtualizar()
		{
			TipoColaboradorModel objTipoColaborador = new TipoColaboradorModel();
						objTipoColaborador.DsTipoColaborador = Request["txtDsTipoColaborador"].ToString();
			objTipoColaborador.IdTipoColaborador = Int32.Parse(Request["IdTipoColaborador"].ToString());
			Response.Write(objTipoColaborador.Alterar());
		}
		[HttpGet]
		public void TipoColaboradorExcluir()
		{
			TipoColaboradorModel objTipoColaborador = new TipoColaboradorModel();
						objTipoColaborador.DsTipoColaborador = "";
			objTipoColaborador.IdTipoColaborador = 0;//Int32.Parse(Request.QueryString["id"].ToString());
			Response.Write(objTipoColaborador.Excluir());
		}
		public ActionResult TipoColaboradorListar()
		{
			return PartialView();
		}
		public ActionResult ExibirDataTable(JQueryDataTablesParamViewModel Params)
		{
			TipoColaboradorModel objTipoColaborador = new TipoColaboradorModel();
			objTipoColaborador.DsTipoColaborador = "";
			objTipoColaborador.IdTipoColaborador = 0;//Int32.Parse(Request.QueryString["id"].ToString());
			int ChaveDados = 0;
			int TotalRegistro = 0;
			int TotalRegistrosFiltrados = 0;//Convert.ToInt32(Request.Params["total"]);
			IEnumerable<TipoColaboradorModel> filteredTipoColaborador = objTipoColaborador.Exibir(ChaveDados, Params, out TotalRegistro, out TotalRegistrosFiltrados);
			var isIdentificadorSortable = Convert.ToBoolean(Request["bSortable_1"]);
			var isDsTipoColaboradorSortable = Convert.ToBoolean(Request["bSortable_2"]);
			var sortColumnIndex = Convert.ToInt32(Request["iSortCol_0"]);
			Func<TipoColaboradorModel, string> orderingTipoColaborador = (c => sortColumnIndex == 1 && isIdentificadorSortable ? c.IdTipoColaborador.ToString() :
															sortColumnIndex == 2 && isDsTipoColaboradorSortable ? c.DsTipoColaborador.ToString() :
															"");
			var sortDirection = Request["sSortDir_0"]; // asc or desc
			if (sortDirection == "asc")
				filteredTipoColaborador = filteredTipoColaborador.OrderBy(orderingTipoColaborador);
			else
				filteredTipoColaborador = filteredTipoColaborador.OrderByDescending(orderingTipoColaborador);
			var result = from c in filteredTipoColaborador select new[] { "", Convert.ToString(c.IdTipoColaborador) , c.DsTipoColaborador };
			return Json(new
			{
				sEcho = Params.sEcho,
				iTotalRecords = TotalRegistro,
				iTotalDisplayRecords = TotalRegistrosFiltrados,
				aaData = result
				}, JsonRequestBehavior.AllowGet);
		}
	}
}

