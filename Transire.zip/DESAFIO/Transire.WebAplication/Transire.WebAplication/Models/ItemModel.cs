﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
namespace Transire.WebAplication.Models
{
	public class ItemModel : ModelImpl<ItemModel>
	{
		#region Propriedades
		public decimal QtPedido { get; set; }
		public decimal VlPedido { get; set; }
		public int IdItem { get; set; }
		#region Umparamuitos
		public ProdutoModel objProduto = new ProdutoModel();
		#endregion //Umparamuitos
		#region Muitosparamuitos
				#endregion //Muitosparamuitos
		#endregion //Propriedades
		#region Metodos
		public ItemModel()
		{
			this.QtPedido = 0;
			this.VlPedido = 0;
			this.IdItem = 0;
			this.objProduto.IdProduto = 0;
		}
		public override string Inserir()
		{
			return this.Persistir(1);
		}
		public override string Alterar()
		{
			return this.Persistir(2);
		}
		public override string Excluir()
		{
			return this.Persistir(3);
		}
		public override string Persistir(int Oper)
		{
			this.conn.Conectar();
			this.conn.Parametros.Clear();
			this.conn.SetarSP("SPE_T009_ITEM_IAD");
			this.conn.AdicionarParametro("IdOperacao",Oper, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("IdUsuarioSys", this._IdColaborador, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("IdProduto", this.objProduto.IdProduto, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtPedido", this.QtPedido, System.Data.SqlDbType.Decimal);
			this.conn.AdicionarParametro("VlPedido", this.VlPedido, System.Data.SqlDbType.Decimal);
			this.conn.AdicionarParametro("IdItem", this.IdItem, System.Data.SqlDbType.Int);
			return this.Execute();
		}
		public override List<ItemModel> Consultar()
		{
			this.conn.Conectar();
			this.conn.Parametros.Clear();
			this.conn.SetarSP("SPE_T009_ITEM_FND");
			this.conn.AdicionarParametro("ChaveDados", 0, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtInicio", 0, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtRegistros", 0, System.Data.SqlDbType.Int);
				this.conn.AdicionarParametro("StringSearch", "", System.Data.SqlDbType.VarChar);
				this.conn.AdicionarParametro("IdItem", this.IdItem, System.Data.SqlDbType.Int);
			List<ItemModel> resultado = new List<ItemModel>();
			try
			{
				SqlDataReader reader = (SqlDataReader)conn.Executar();
				while (reader.Read())
				{
					ItemModel objItem = new ItemModel();
					objItem.objProduto.IdProduto = Int32.Parse(reader["T002ID_PRODUTO"].ToString());
					objItem.QtPedido = decimal.Parse(reader["T009QT_PEDIDO"].ToString());
					objItem.VlPedido = decimal.Parse(reader["T009VL_PEDIDO"].ToString());
					objItem.IdItem = Int32.Parse(reader["T009ID_ITEM"].ToString());
					resultado.Add(objItem);
				}
				conn.Desconectar();
				return resultado;
			}
			catch (SqlException)
			{
				return resultado;
			}
		}
		public override List<ItemModel> Exibir(int ChaveDados, JQueryDataTablesParamViewModel Params, out int TotalRegistro, out int TotalRegistrosFiltrados)
		{
			TotalRegistro = 0;
			TotalRegistrosFiltrados = 0;
			this.conn.Conectar();
			this.conn.Parametros.Clear();
			this.conn.SetarSP("SPE_T009_ITEM_FND");
			this.conn.AdicionarParametro("ChaveDados", ChaveDados, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtInicio", Params.iDisplayStart, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtRegistros", Params.iDisplayLength, System.Data.SqlDbType.Int);
			if (!string.IsNullOrEmpty(Params.sSearch))
			{
				this.conn.AdicionarParametro("StringSearch", Params.sSearch.ToLower(), System.Data.SqlDbType.VarChar);
			}
			else
			{
				this.conn.AdicionarParametro("StringSearch", "", System.Data.SqlDbType.VarChar);
			}
						List<ItemModel> resultado = new List<ItemModel>();
			try
			{
				SqlDataReader reader = (SqlDataReader)conn.Executar();
				while (reader.Read())
				{
					TotalRegistro = Convert.ToInt32(reader["Total"]);
					TotalRegistrosFiltrados = Convert.ToInt32(reader["TotalFiltrado"]);
					ItemModel objItem = new ItemModel();
					objItem.objProduto.IdProduto = Int32.Parse(reader["T002ID_PRODUTO"].ToString());
					objItem.objProduto.DsProduto = reader["T002DS_PRODUTO"].ToString();
					objItem.QtPedido = decimal.Parse(reader["T009QT_PEDIDO"].ToString());
					objItem.VlPedido = decimal.Parse(reader["T009VL_PEDIDO"].ToString());
					objItem.IdItem = Int32.Parse(reader["T009ID_ITEM"].ToString());
					resultado.Add(objItem);
				}
				conn.Desconectar();
				return resultado;
			}
			catch (SqlException)
			{
				return resultado;
			}
		}
		#endregion
	}
}

