﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
namespace Transire.WebAplication.Models
{
	public class LojaModel : ModelImpl<LojaModel>
	{
		#region Propriedades
		public string DsLoja { get; set; }
		public DateTime DtCadastro { get; set; }
		public int IdLoja { get; set; }
		#region Umparamuitos
				#endregion //Umparamuitos
		#region Muitosparamuitos
		//public LojaProdutoModel objLojaProduto = new LojaProdutoModel();
		#endregion //Muitosparamuitos
		#endregion //Propriedades
		#region Metodos
		public LojaModel()
		{
			this.DsLoja = "";
			this.DtCadastro = DateTime.Parse("01/01/9999");
			this.IdLoja = 0;
					}
		public override string Inserir()
		{
			return this.Persistir(1);
		}
		public override string Alterar()
		{
			return this.Persistir(2);
		}
		public override string Excluir()
		{
			return this.Persistir(3);
		}
		public override string Persistir(int Oper)
		{
			this.conn.Conectar();
			this.conn.Parametros.Clear();
			this.conn.SetarSP("SPE_T001_LOJA_IAD");
			this.conn.AdicionarParametro("IdOperacao",Oper, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("IdUsuarioSys", this._IdColaborador, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("DsLoja", this.DsLoja.ToUpper(), System.Data.SqlDbType.VarChar);
			this.conn.AdicionarParametro("DtCadastro", this.DtCadastro, System.Data.SqlDbType.DateTime);
			this.conn.AdicionarParametro("IdLoja", this.IdLoja, System.Data.SqlDbType.Int);
			return this.Execute();
		}
		public override List<LojaModel> Consultar()
		{
			this.conn.Conectar();
			this.conn.Parametros.Clear();
			this.conn.SetarSP("SPE_T001_LOJA_FND");
			this.conn.AdicionarParametro("ChaveDados", 0, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtInicio", 0, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtRegistros", 0, System.Data.SqlDbType.Int);
				this.conn.AdicionarParametro("StringSearch", "", System.Data.SqlDbType.VarChar);
				this.conn.AdicionarParametro("IdLoja", this.IdLoja, System.Data.SqlDbType.Int);
			List<LojaModel> resultado = new List<LojaModel>();
			try
			{
				SqlDataReader reader = (SqlDataReader)conn.Executar();
				while (reader.Read())
				{
					LojaModel objLoja = new LojaModel();
					objLoja.DsLoja = reader["T001DS_LOJA"].ToString();
					objLoja.DtCadastro = DateTime.Parse(reader["T001DT_CADASTRO"].ToString());
					objLoja.IdLoja = Int32.Parse(reader["T001ID_LOJA"].ToString());
					resultado.Add(objLoja);
				}
				conn.Desconectar();
				return resultado;
			}
			catch (SqlException)
			{
				return resultado;
			}
		}
		public override List<LojaModel> Exibir(int ChaveDados, JQueryDataTablesParamViewModel Params, out int TotalRegistro, out int TotalRegistrosFiltrados)
		{
			TotalRegistro = 0;
			TotalRegistrosFiltrados = 0;
			this.conn.Conectar();
			this.conn.Parametros.Clear();
			this.conn.SetarSP("SPE_T001_LOJA_FND");
			this.conn.AdicionarParametro("ChaveDados", ChaveDados, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtInicio", Params.iDisplayStart, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtRegistros", Params.iDisplayLength, System.Data.SqlDbType.Int);
			if (!string.IsNullOrEmpty(Params.sSearch))
			{
				this.conn.AdicionarParametro("StringSearch", Params.sSearch.ToLower(), System.Data.SqlDbType.VarChar);
			}
			else
			{
				this.conn.AdicionarParametro("StringSearch", "", System.Data.SqlDbType.VarChar);
			}
			this.conn.AdicionarParametro("DtCadastro", this.DtCadastro, System.Data.SqlDbType.DateTime);
			List<LojaModel> resultado = new List<LojaModel>();
			try
			{
				SqlDataReader reader = (SqlDataReader)conn.Executar();
				while (reader.Read())
				{
					TotalRegistro = Convert.ToInt32(reader["Total"]);
					TotalRegistrosFiltrados = Convert.ToInt32(reader["TotalFiltrado"]);
					LojaModel objLoja = new LojaModel();
					objLoja.DsLoja = reader["T001DS_LOJA"].ToString();
					objLoja.DtCadastro = DateTime.Parse(reader["T001DT_CADASTRO"].ToString());
					objLoja.IdLoja = Int32.Parse(reader["T001ID_LOJA"].ToString());
					resultado.Add(objLoja);
				}
				conn.Desconectar();
				return resultado;
			}
			catch (SqlException)
			{
				return resultado;
			}
		}
		#endregion
	}
}

