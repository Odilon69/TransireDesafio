﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
namespace Transire.WebAplication.Models
{
	public class PedidoModel : ModelImpl<PedidoModel>
	{
		#region Propriedades
		public DateTime TPedido { get; set; }
		public int IdPedido { get; set; }
		#region Umparamuitos
		public ColaboradorModel objColaborador = new ColaboradorModel();
		#endregion //Umparamuitos
		#region Muitosparamuitos
		//public PedidoItemModel objPedidoItem = new PedidoItemModel();
		//public ClientePedidoModel objClientePedido = new ClientePedidoModel();
		#endregion //Muitosparamuitos
		#endregion //Propriedades
		#region Metodos
		public PedidoModel()
		{
			this.TPedido = DateTime.Parse("01/01/9999");
			this.IdPedido = 0;
			this.objColaborador.IdColaborador = 0;//IdVendedor
		}
		public override string Inserir()
		{
			return this.Persistir(1);
		}
		public override string Alterar()
		{
			return this.Persistir(2);
		}
		public override string Excluir()
		{
			return this.Persistir(3);
		}
		public override string Persistir(int Oper)
		{
			this.conn.Conectar();
			this.conn.Parametros.Clear();
			this.conn.SetarSP("SPE_T008_PEDIDO_IAD");
			this.conn.AdicionarParametro("IdOperacao",Oper, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("IdUsuarioSys", this._IdColaborador, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("IdVendedor", this.objColaborador.IdColaborador, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("TPedido", this.TPedido, System.Data.SqlDbType.DateTime);
			this.conn.AdicionarParametro("IdPedido", this.IdPedido, System.Data.SqlDbType.Int);
			return this.Execute();
		}
		public override List<PedidoModel> Consultar()
		{
			this.conn.Conectar();
			this.conn.Parametros.Clear();
			this.conn.SetarSP("SPE_T008_PEDIDO_FND");
			this.conn.AdicionarParametro("ChaveDados", 0, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtInicio", 0, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtRegistros", 0, System.Data.SqlDbType.Int);
				this.conn.AdicionarParametro("StringSearch", "", System.Data.SqlDbType.VarChar);
				this.conn.AdicionarParametro("IdPedido", this.IdPedido, System.Data.SqlDbType.Int);
			List<PedidoModel> resultado = new List<PedidoModel>();
			try
			{
				SqlDataReader reader = (SqlDataReader)conn.Executar();
				while (reader.Read())
				{
					PedidoModel objPedido = new PedidoModel();
					objPedido.objColaborador.IdColaborador = Int32.Parse(reader["T006ID_VENDEDOR"].ToString());
					objPedido.TPedido = DateTime.Parse(reader["T00DT_PEDIDO"].ToString());
					objPedido.IdPedido = Int32.Parse(reader["T008ID_PEDIDO"].ToString());
					resultado.Add(objPedido);
				}
				conn.Desconectar();
				return resultado;
			}
			catch (SqlException)
			{
				return resultado;
			}
		}
		public override List<PedidoModel> Exibir(int ChaveDados, JQueryDataTablesParamViewModel Params, out int TotalRegistro, out int TotalRegistrosFiltrados)
		{
			TotalRegistro = 0;
			TotalRegistrosFiltrados = 0;
			this.conn.Conectar();
			this.conn.Parametros.Clear();
			this.conn.SetarSP("SPE_T008_PEDIDO_FND");
			this.conn.AdicionarParametro("ChaveDados", ChaveDados, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtInicio", Params.iDisplayStart, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtRegistros", Params.iDisplayLength, System.Data.SqlDbType.Int);
			if (!string.IsNullOrEmpty(Params.sSearch))
			{
				this.conn.AdicionarParametro("StringSearch", Params.sSearch.ToLower(), System.Data.SqlDbType.VarChar);
			}
			else
			{
				this.conn.AdicionarParametro("StringSearch", "", System.Data.SqlDbType.VarChar);
			}
			this.conn.AdicionarParametro("TPedido", this.TPedido, System.Data.SqlDbType.DateTime);
			List<PedidoModel> resultado = new List<PedidoModel>();
			try
			{
				SqlDataReader reader = (SqlDataReader)conn.Executar();
				while (reader.Read())
				{
					TotalRegistro = Convert.ToInt32(reader["Total"]);
					TotalRegistrosFiltrados = Convert.ToInt32(reader["TotalFiltrado"]);
					PedidoModel objPedido = new PedidoModel();
					objPedido.objColaborador.IdColaborador = Int32.Parse(reader["T006ID_VENDEDOR"].ToString());
					objPedido.objColaborador.NmColaborador = reader["T006NM_COLABORADOR"].ToString();
					objPedido.TPedido = DateTime.Parse(reader["T00DT_PEDIDO"].ToString());
					objPedido.IdPedido = Int32.Parse(reader["T008ID_PEDIDO"].ToString());
					resultado.Add(objPedido);
				}
				conn.Desconectar();
				return resultado;
			}
			catch (SqlException)
			{
				return resultado;
			}
		}
		#endregion
	}
}

