﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
namespace Transire.WebAplication.Models
{
	public class StatusProdutoModel : ModelImpl<StatusProdutoModel>
	{
		#region Propriedades
		public string DsStatusProduto { get; set; }
		public string FgClass { get; set; }
		public int IdStatusProduto { get; set; }
		#region Umparamuitos
				#endregion //Umparamuitos
		#region Muitosparamuitos
				#endregion //Muitosparamuitos
		#endregion //Propriedades
		#region Metodos
		public StatusProdutoModel()
		{
			this.DsStatusProduto = "";
			this.FgClass = "";
			this.IdStatusProduto = 0;
					}
		public override string Inserir()
		{
			return this.Persistir(1);
		}
		public override string Alterar()
		{
			return this.Persistir(2);
		}
		public override string Excluir()
		{
			return this.Persistir(3);
		}
		public override string Persistir(int Oper)
		{
			this.conn.Conectar();
			this.conn.Parametros.Clear();
			this.conn.SetarSP("SPE_T005_STATUS_PRODUTO_IAD");
			this.conn.AdicionarParametro("IdOperacao",Oper, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("IdUsuarioSys", this._IdColaborador, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("DsStatusProduto", this.DsStatusProduto.ToUpper(), System.Data.SqlDbType.VarChar);
			this.conn.AdicionarParametro("FgClass", this.FgClass.ToUpper(), System.Data.SqlDbType.VarChar);
			this.conn.AdicionarParametro("IdStatusProduto", this.IdStatusProduto, System.Data.SqlDbType.Int);
			return this.Execute();
		}
		public override List<StatusProdutoModel> Consultar()
		{
			this.conn.Conectar();
			this.conn.Parametros.Clear();
			this.conn.SetarSP("SPE_T005_STATUS_PRODUTO_FND");
			this.conn.AdicionarParametro("ChaveDados", 0, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtInicio", 0, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtRegistros", 0, System.Data.SqlDbType.Int);
				this.conn.AdicionarParametro("StringSearch", "", System.Data.SqlDbType.VarChar);
				this.conn.AdicionarParametro("IdStatusProduto", this.IdStatusProduto, System.Data.SqlDbType.Int);
			List<StatusProdutoModel> resultado = new List<StatusProdutoModel>();
			try
			{
				SqlDataReader reader = (SqlDataReader)conn.Executar();
				while (reader.Read())
				{
					StatusProdutoModel objStatusProduto = new StatusProdutoModel();
					objStatusProduto.DsStatusProduto = reader["T005DS_STATUS_PRODUTO"].ToString();
					objStatusProduto.FgClass = reader["T005FG_CLASS"].ToString();
					objStatusProduto.IdStatusProduto = Int32.Parse(reader["T005ID_STATUS_PRODUTO"].ToString());
					resultado.Add(objStatusProduto);
				}
				conn.Desconectar();
				return resultado;
			}
			catch (SqlException)
			{
				return resultado;
			}
		}
		public override List<StatusProdutoModel> Exibir(int ChaveDados, JQueryDataTablesParamViewModel Params, out int TotalRegistro, out int TotalRegistrosFiltrados)
		{
			TotalRegistro = 0;
			TotalRegistrosFiltrados = 0;
			this.conn.Conectar();
			this.conn.Parametros.Clear();
			this.conn.SetarSP("SPE_T005_STATUS_PRODUTO_FND");
			this.conn.AdicionarParametro("ChaveDados", ChaveDados, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtInicio", Params.iDisplayStart, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtRegistros", Params.iDisplayLength, System.Data.SqlDbType.Int);
			if (!string.IsNullOrEmpty(Params.sSearch))
			{
				this.conn.AdicionarParametro("StringSearch", Params.sSearch.ToLower(), System.Data.SqlDbType.VarChar);
			}
			else
			{
				this.conn.AdicionarParametro("StringSearch", "", System.Data.SqlDbType.VarChar);
			}
						List<StatusProdutoModel> resultado = new List<StatusProdutoModel>();
			try
			{
				SqlDataReader reader = (SqlDataReader)conn.Executar();
				while (reader.Read())
				{
					TotalRegistro = Convert.ToInt32(reader["Total"]);
					TotalRegistrosFiltrados = Convert.ToInt32(reader["TotalFiltrado"]);
					StatusProdutoModel objStatusProduto = new StatusProdutoModel();
					objStatusProduto.DsStatusProduto = reader["T005DS_STATUS_PRODUTO"].ToString();
					objStatusProduto.FgClass = reader["T005FG_CLASS"].ToString();
					objStatusProduto.IdStatusProduto = Int32.Parse(reader["T005ID_STATUS_PRODUTO"].ToString());
					resultado.Add(objStatusProduto);
				}
				conn.Desconectar();
				return resultado;
			}
			catch (SqlException)
			{
				return resultado;
			}
		}
		#endregion
	}
}

