﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
namespace Transire.WebAplication.Models
{
	public class TipoColaboradorModel : ModelImpl<TipoColaboradorModel>
	{
		#region Propriedades
		public string DsTipoColaborador { get; set; }
		public int IdTipoColaborador { get; set; }
		#region Umparamuitos
				#endregion //Umparamuitos
		#region Muitosparamuitos
				#endregion //Muitosparamuitos
		#endregion //Propriedades
		#region Metodos
		public TipoColaboradorModel()
		{
			this.DsTipoColaborador = "";
			this.IdTipoColaborador = 0;
					}
		public override string Inserir()
		{
			return this.Persistir(1);
		}
		public override string Alterar()
		{
			return this.Persistir(2);
		}
		public override string Excluir()
		{
			return this.Persistir(3);
		}
		public override string Persistir(int Oper)
		{
			this.conn.Conectar();
			this.conn.Parametros.Clear();
			this.conn.SetarSP("SPE_T007_TIPO_COLABORADOR_IAD");
			this.conn.AdicionarParametro("IdOperacao",Oper, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("IdUsuarioSys", this._IdColaborador, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("DsTipoColaborador", this.DsTipoColaborador.ToUpper(), System.Data.SqlDbType.VarChar);
			this.conn.AdicionarParametro("IdTipoColaborador", this.IdTipoColaborador, System.Data.SqlDbType.Int);
			return this.Execute();
		}
		public override List<TipoColaboradorModel> Consultar()
		{
			this.conn.Conectar();
			this.conn.Parametros.Clear();
			this.conn.SetarSP("SPE_T007_TIPO_COLABORADOR_FND");
			this.conn.AdicionarParametro("ChaveDados", 0, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtInicio", 0, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtRegistros", 0, System.Data.SqlDbType.Int);
				this.conn.AdicionarParametro("StringSearch", "", System.Data.SqlDbType.VarChar);
				this.conn.AdicionarParametro("IdTipoColaborador", this.IdTipoColaborador, System.Data.SqlDbType.Int);
			List<TipoColaboradorModel> resultado = new List<TipoColaboradorModel>();
			try
			{
				SqlDataReader reader = (SqlDataReader)conn.Executar();
				while (reader.Read())
				{
					TipoColaboradorModel objTipoColaborador = new TipoColaboradorModel();
					objTipoColaborador.DsTipoColaborador = reader["T007DS_TIPO_COLABORADOR"].ToString();
					objTipoColaborador.IdTipoColaborador = Int32.Parse(reader["T007ID_TIPO_COLABORADOR"].ToString());
					resultado.Add(objTipoColaborador);
				}
				conn.Desconectar();
				return resultado;
			}
			catch (SqlException)
			{
				return resultado;
			}
		}
		public override List<TipoColaboradorModel> Exibir(int ChaveDados, JQueryDataTablesParamViewModel Params, out int TotalRegistro, out int TotalRegistrosFiltrados)
		{
			TotalRegistro = 0;
			TotalRegistrosFiltrados = 0;
			this.conn.Conectar();
			this.conn.Parametros.Clear();
			this.conn.SetarSP("SPE_T007_TIPO_COLABORADOR_FND");
			this.conn.AdicionarParametro("ChaveDados", ChaveDados, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtInicio", Params.iDisplayStart, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtRegistros", Params.iDisplayLength, System.Data.SqlDbType.Int);
			if (!string.IsNullOrEmpty(Params.sSearch))
			{
				this.conn.AdicionarParametro("StringSearch", Params.sSearch.ToLower(), System.Data.SqlDbType.VarChar);
			}
			else
			{
				this.conn.AdicionarParametro("StringSearch", "", System.Data.SqlDbType.VarChar);
			}
						List<TipoColaboradorModel> resultado = new List<TipoColaboradorModel>();
			try
			{
				SqlDataReader reader = (SqlDataReader)conn.Executar();
				while (reader.Read())
				{
					TotalRegistro = Convert.ToInt32(reader["Total"]);
					TotalRegistrosFiltrados = Convert.ToInt32(reader["TotalFiltrado"]);
					TipoColaboradorModel objTipoColaborador = new TipoColaboradorModel();
					objTipoColaborador.DsTipoColaborador = reader["T007DS_TIPO_COLABORADOR"].ToString();
					objTipoColaborador.IdTipoColaborador = Int32.Parse(reader["T007ID_TIPO_COLABORADOR"].ToString());
					resultado.Add(objTipoColaborador);
				}
				conn.Desconectar();
				return resultado;
			}
			catch (SqlException)
			{
				return resultado;
			}
		}
		#endregion
	}
}

