﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
namespace Transire.WebAplication.Models
{
    public class UnidadeMedidaModel : ModelImpl<UnidadeMedidaModel>
    {
        #region Propriedades
        public string DsUnidadeMedida { get; set; }
        public int IdUnidadeMedida { get; set; }
        #region Umparamuitos
        #endregion //Umparamuitos
        #region Muitosparamuitos
        #endregion //Muitosparamuitos
        #endregion //Propriedades
        #region Metodos
        public UnidadeMedidaModel()
        {
            this.DsUnidadeMedida = "";
            this.IdUnidadeMedida = 0;
        }
        public override string Inserir()
        {
            return this.Persistir(1);
        }
        public override string Alterar()
        {
            return this.Persistir(2);
        }
        public override string Excluir()
        {
            return this.Persistir(3);
        }
        public override string Persistir(int Oper)
        {
            this.conn.Conectar();
            this.conn.Parametros.Clear();
            this.conn.SetarSP("SPE_T011_UNIDADE_MEDIDA_IAD");
            this.conn.AdicionarParametro("IdOperacao", Oper, System.Data.SqlDbType.Int);
            this.conn.AdicionarParametro("IdUsuarioSys", this._IdColaborador, System.Data.SqlDbType.Int);
            this.conn.AdicionarParametro("DsUnidadeMedida", this.DsUnidadeMedida.ToUpper(), System.Data.SqlDbType.VarChar);
            this.conn.AdicionarParametro("IdUnidadeMedida", this.IdUnidadeMedida, System.Data.SqlDbType.Int);
            return this.Execute();
        }
        public override List<UnidadeMedidaModel> Consultar()
        {
            this.conn.Conectar();
            this.conn.Parametros.Clear();
            this.conn.SetarSP("SPE_T011_UNIDADE_MEDIDA_FND");
            this.conn.AdicionarParametro("ChaveDados", 0, System.Data.SqlDbType.Int);
            this.conn.AdicionarParametro("QtInicio", 0, System.Data.SqlDbType.Int);
            this.conn.AdicionarParametro("QtRegistros", 0, System.Data.SqlDbType.Int);
            this.conn.AdicionarParametro("StringSearch", "", System.Data.SqlDbType.VarChar);
            this.conn.AdicionarParametro("IdUnidadeMedida", this.IdUnidadeMedida, System.Data.SqlDbType.Int);
            List<UnidadeMedidaModel> resultado = new List<UnidadeMedidaModel>();
            try
            {
                SqlDataReader reader = (SqlDataReader)conn.Executar();
                while (reader.Read())
                {
                    UnidadeMedidaModel objUnidadeMedida = new UnidadeMedidaModel();
                    objUnidadeMedida.DsUnidadeMedida = reader["T011DS_UNIDADE_MEDIDA"].ToString();
                    objUnidadeMedida.IdUnidadeMedida = Int32.Parse(reader["T011ID_UNIDADE_MEDIDA"].ToString());
                    resultado.Add(objUnidadeMedida);
                }
                conn.Desconectar();
                return resultado;
            }
            catch (SqlException)
            {
                return resultado;
            }
        }
        public override List<UnidadeMedidaModel> Exibir(int ChaveDados, JQueryDataTablesParamViewModel Params, out int TotalRegistro, out int TotalRegistrosFiltrados)
        {
            TotalRegistro = 0;
            TotalRegistrosFiltrados = 0;
            this.conn.Conectar();
            this.conn.Parametros.Clear();
            this.conn.SetarSP("SPE_T011_UNIDADE_MEDIDA_FND");
            this.conn.AdicionarParametro("ChaveDados", ChaveDados, System.Data.SqlDbType.Int);
            this.conn.AdicionarParametro("QtInicio", Params.iDisplayStart, System.Data.SqlDbType.Int);
            this.conn.AdicionarParametro("QtRegistros", Params.iDisplayLength, System.Data.SqlDbType.Int);
            if (!string.IsNullOrEmpty(Params.sSearch))
            {
                this.conn.AdicionarParametro("StringSearch", Params.sSearch.ToLower(), System.Data.SqlDbType.VarChar);
            }
            else
            {
                this.conn.AdicionarParametro("StringSearch", "", System.Data.SqlDbType.VarChar);
            }
            List<UnidadeMedidaModel> resultado = new List<UnidadeMedidaModel>();
            try
            {
                SqlDataReader reader = (SqlDataReader)conn.Executar();
                while (reader.Read())
                {
                    TotalRegistro = Convert.ToInt32(reader["Total"]);
                    TotalRegistrosFiltrados = Convert.ToInt32(reader["TotalFiltrado"]);
                    UnidadeMedidaModel objUnidadeMedida = new UnidadeMedidaModel();
                    objUnidadeMedida.DsUnidadeMedida = reader["T011DS_UNIDADE_MEDIDA"].ToString();
                    objUnidadeMedida.IdUnidadeMedida = Int32.Parse(reader["T011ID_UNIDADE_MEDIDA"].ToString());
                    resultado.Add(objUnidadeMedida);
                }
                conn.Desconectar();
                return resultado;
            }
            catch (SqlException)
            {
                return resultado;
            }
        }
        #endregion
    }
}

