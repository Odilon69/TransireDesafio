﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Transire.WebAplication.Models
{
    public abstract class ModelImpl<T> : IModel<T>
    {
        public Controllers.SqlDbConnect conn = Controllers.SqlDbConnect.getInstance();

        private int __IdColaborador;
        public int _IdColaborador 
        {
            get 
            {
                int idcol = 0;

                try
                {
                    //Transire.Util.SessionHandler sessionHandler = new Transire.Util.SessionHandler();
                    idcol = 0;//sessionHandler.LoginModel.objColaborador.IdColaborador;
                }
                catch (Exception)
                {
                    idcol = 0;
                }

                if (__IdColaborador > 0)
                    return __IdColaborador;
                else
                    return idcol;
            }
            set
            {
                __IdColaborador = value;
            }
        }
        
        public string message = "";


        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public string Execute()
        {
            try
            {
                System.Data.SqlClient.SqlDataReader reader = (System.Data.SqlClient.SqlDataReader)conn.Executar();

                if (reader.Read())
                {
                    message = reader["Resp"].ToString();
                }

                reader.Close();
                conn.Desconectar();
                return message;
            }
            catch (System.Data.SqlClient.SqlException)
            {
                return "erro|Favor tentar novamente, ou entrar em contato com o administrador!";
            }
        }

        public abstract string Inserir();

        public abstract string Alterar();

        public abstract string Excluir();

        public abstract string Persistir(int Oper);

        public abstract List<T> Consultar();

        public abstract List<T> Exibir(int ChaveDados, JQueryDataTablesParamViewModel Params, out int TotalRegistro, out int TotalRegistrosFiltrados);
        //public abstract FlexgridComMVC.Helpers.Flexigrid Exibir(FlexgridComMVC.Helpers.Flexigrid objFlex);

     
    }
}