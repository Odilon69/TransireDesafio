﻿$(function ()
	{
		$("#buttonSalvar").click
		(function () 
			{
					fn_ajaxPost(path + "/Produto/ProdutoSalvar", "myForm", "Enviando dados!", "");
			}
		);
    $("#buttonVoltar").click
        (function () {
            Fn_AjaxGet(path + "/Produto/ProdutoListar", "definicaoArquitetura", "Carregando !", "");
        }
        );

    $("#buttonAlterar").click
		(function () 
		{
				    fn_ajaxPost(path + "/Produto/ProdutoAtualizar", "myForm", "Enviando dados!", function retorno(data)
						{
							if (data[0] == "sucesso") 
							{
							    Fn_AjaxGet(path + "/Produto/ProdutoListar", "definicaoArquitetura", "Carregando !", "");
							}
						}
					);
			}
		);
	}
);

