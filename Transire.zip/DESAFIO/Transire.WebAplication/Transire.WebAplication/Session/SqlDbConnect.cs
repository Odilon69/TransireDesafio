﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.Data;
using System.Data.OleDb;
using System.Collections;
using System.Data.SqlClient;

namespace Transire.WebAplication.Controllers
{
    public class SqlDbConnect
    {
        #region Attributes

        private bool _isvalid;
        private string _message;
        //private string _stringConnection;
        private SqlConnection _connection;
        private DataTable _tabela;
        private IList _parametros = new ArrayList();
        private SqlTransaction _transaction;
        private SqlCommand _command;

        private static SqlDbConnect instace;

        #endregion

        
        // Propriedades de conexão
        #region Properties

        //public string StringConnection
        //{
        //    get { return _stringConnection; }
        //    set { _stringConnection = value; }
        //}

        //public SqlConnection Connection
        //{
        //    get { return _connection; }
        //    set { _connection = value; }
        //}

        public DataTable Tabela
        {
            get { return _tabela; }
            set { _tabela = value; }
        }

        public IList Parametros
        {
            get { return _parametros; }
            set { _parametros = value; }
        }

        public SqlTransaction Transaction
        {
            get { return _transaction; }
            set { _transaction = value; }
        }

        public bool Isvalid
        {
            get { return _isvalid; }
            set { _isvalid = value; }
        }

        public string Message
        {
            get { return _message; }
            set { _message = value; }
        }

        #endregion


        // Métodos de conexão
        #region Methods

        public static SqlDbConnect getInstance()
        {
            if(instace == null)
                instace = new SqlDbConnect();

            return instace;
        }

        // Método conectar, que tenta estabelecer conexão com a base de dados
        public bool Conectar()
        {
            try
            {
                if ((_connection != null) && (_connection.State == ConnectionState.Open))
                {
                    return true;
                }
                else
                {
                    // Verifica o estado da conexão, se estiver fechado, abre uma nova

                    // String de conexão retirada da Web.config
                    string _connectionString = ConfigurationManager.ConnectionStrings["DefaultStringConnection"].ConnectionString;

                    _connection = new SqlConnection(_connectionString);

                    _connection.Open();
                    return true;
                }
            }
            catch (Exception erro)
            {
                Message = erro.Message;
                return false;
            }
        }


        // Método desconectar, que finaliza a conexão atual
        public void Desconectar()
        {
            try
            {
                // Verifica o estado da conexão, se estiver aberta, finaliza a conexão
               _connection.Close();
               }
            catch (Exception) { }
        }


        // Adiciona parâmetros de entrada ao SqlParameter
        public void AdicionarParametro(string nome, object valor, SqlDbType tipo)
        {
            SqlParameter parametro = new SqlParameter(nome, tipo);
            parametro.Direction = ParameterDirection.Input;
            parametro.Value = valor;

            _parametros.Add(parametro);
        }

        // Adiciona parâmetros de saída ao SqlParameter 
        public void AdicionarParametroSaida(string nome, SqlDbType tipo)
        {
            SqlParameter parametro = new SqlParameter(nome, tipo);
            parametro.Direction = ParameterDirection.Output;

            _parametros.Add(parametro);
        }

        // Seta o comando SQL
        public void SetarSQL(string SQL)
        {
            _command = new SqlCommand();
            _command.CommandType = CommandType.Text;
            _command.CommandText = SQL;
            _command.Connection = _connection;
            _command.CommandTimeout = 0;
        }

        // Seta a Stored Procedure
        public void SetarSP(string nomeSP)
        {
            _command = new SqlCommand();
            _command.CommandType = CommandType.StoredProcedure;
            _command.CommandText = nomeSP;
            _command.Connection = _connection;
            _command.CommandTimeout = 0;
        }

        public SqlDataReader Executar()
        {
            SqlDataReader reader = null;

            try
            {
                foreach (SqlParameter parametro in _parametros)
                {
                    _command.Parameters.Add(parametro);
                }

                reader = _command.ExecuteReader();
                return reader;
            }
            catch (Exception)
            {
                _command.Cancel();
                this._connection.Close();
                return reader;
            }
         }

        #endregion
    }
}