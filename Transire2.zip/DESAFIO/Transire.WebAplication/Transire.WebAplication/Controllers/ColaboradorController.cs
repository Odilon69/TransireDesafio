﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Transire.WebAplication.Models;
namespace Transire.WebAplication.Controllers
{
	public class ColaboradorController : Controller
	{
		public ActionResult ColaboradorCadastrar()
		{
			ViewBag.listDsTipoColaborador = new SelectList(new TipoColaboradorModel().Consultar(), "IdTipoColaborador","DsTipoColaborador");
			return PartialView();
		}
		public ActionResult ColaboradorAlterar()
		{
			ColaboradorModel objColaborador = new ColaboradorModel();
			objColaborador.IdColaborador = Int32.Parse(Request.QueryString["id"].ToString());
			List<ColaboradorModel> listColaborador =  objColaborador.Consultar();
			ViewBag.listDsTipoColaborador = new SelectList(new TipoColaboradorModel().Consultar(), "IdTipoColaborador","DsTipoColaborador", listColaborador[0].objTipoColaborador.IdTipoColaborador);
			ViewBag.txtNmColaborador = listColaborador[0].NmColaborador.ToString();
			ViewBag.txtDsEndereco = listColaborador[0].DsEndereco.ToString();
			ViewBag.txtNmCidade = listColaborador[0].NmCidade.ToString();
			ViewBag.txtNmUf = listColaborador[0].NmUf.ToString();
			ViewBag.txtNrCnpjCpf = listColaborador[0].NrCnpjCpf.ToString();
			ViewBag.txtNrTelefone = listColaborador[0].NrTelefone.ToString();
			ViewBag.IdColaborador = listColaborador[0].IdColaborador.ToString();
			return PartialView();
		}
		[HttpPost]
		public void ColaboradorSalvar()
		{
			ColaboradorModel objColaborador = new ColaboradorModel();
			objColaborador.objTipoColaborador.IdTipoColaborador = Int32.Parse(Request["cboDsTipoColaborador"].ToString());
			objColaborador.NmColaborador = Request["txtNmColaborador"].ToString();
			objColaborador.DsEndereco = Request["txtDsEndereco"].ToString();
			objColaborador.NmCidade = Request["txtNmCidade"].ToString();
			objColaborador.NmUf = Request["txtNmUf"].ToString();
			objColaborador.NrCnpjCpf = Request["txtNrCnpjCpf"].ToString();
			objColaborador.NrTelefone = Request["txtNrTelefone"].ToString();
			string _response = objColaborador.Inserir();
			if (_response.Split('|')[0].Equals("sucesso"))
			{
			}
			else
			{
			}
			Response.Write(_response);
		}
		[HttpPost]
		public void ColaboradorAtualizar()
		{
			ColaboradorModel objColaborador = new ColaboradorModel();
			objColaborador.objTipoColaborador.IdTipoColaborador = Int32.Parse(Request["cboDsTipoColaborador"].ToString());
			objColaborador.NmColaborador = Request["txtNmColaborador"].ToString();
			objColaborador.DsEndereco = Request["txtDsEndereco"].ToString();
			objColaborador.NmCidade = Request["txtNmCidade"].ToString();
			objColaborador.NmUf = Request["txtNmUf"].ToString();
			objColaborador.NrCnpjCpf = Request["txtNrCnpjCpf"].ToString();
			objColaborador.NrTelefone = Request["txtNrTelefone"].ToString();
			objColaborador.IdColaborador = Int32.Parse(Request["IdColaborador"].ToString());
			Response.Write(objColaborador.Alterar());
		}
		[HttpGet]
		public void ColaboradorExcluir()
		{
			ColaboradorModel objColaborador = new ColaboradorModel();
			objColaborador.objTipoColaborador.IdTipoColaborador =  0;
			objColaborador.NmColaborador = "";
			objColaborador.DsEndereco = "";
			objColaborador.NmCidade = "";
			objColaborador.NmUf = "";
			objColaborador.NrCnpjCpf = "";
			objColaborador.NrTelefone = "";
			objColaborador.IdColaborador = 0;//Int32.Parse(Request.QueryString["id"].ToString());
			Response.Write(objColaborador.Excluir());
		}
		public ActionResult ColaboradorListar()
		{
			return PartialView();
		}
		public ActionResult ExibirDataTable(JQueryDataTablesParamViewModel Params)
		{
			ColaboradorModel objColaborador = new ColaboradorModel();
			objColaborador.objTipoColaborador.IdTipoColaborador =  0;
			objColaborador.NmColaborador = "";
			objColaborador.DsEndereco = "";
			objColaborador.NmCidade = "";
			objColaborador.NmUf = "";
			objColaborador.NrCnpjCpf = "";
			objColaborador.NrTelefone = "";
			objColaborador.IdColaborador = 0;//Int32.Parse(Request.QueryString["id"].ToString());
			int ChaveDados = 0;
			int TotalRegistro = 0;
			int TotalRegistrosFiltrados = 0;//Convert.ToInt32(Request.Params["total"]);
			IEnumerable<ColaboradorModel> filteredColaborador = objColaborador.Exibir(ChaveDados, Params, out TotalRegistro, out TotalRegistrosFiltrados);
			var isIdentificadorSortable = Convert.ToBoolean(Request["bSortable_1"]);
			var isDsTipoColaboradorSortable = Convert.ToBoolean(Request["bSortable_2"]);
			var isNmColaboradorSortable = Convert.ToBoolean(Request["bSortable_3"]);
			var isDsEnderecoSortable = Convert.ToBoolean(Request["bSortable_4"]);
			var isNmCidadeSortable = Convert.ToBoolean(Request["bSortable_5"]);
			var isNmUfSortable = Convert.ToBoolean(Request["bSortable_6"]);
			var isNrCnpjCpfSortable = Convert.ToBoolean(Request["bSortable_7"]);
			var isNrTelefoneSortable = Convert.ToBoolean(Request["bSortable_8"]);
			var sortColumnIndex = Convert.ToInt32(Request["iSortCol_0"]);
			Func<ColaboradorModel, string> orderingColaborador = (c => sortColumnIndex == 1 && isIdentificadorSortable ? c.IdColaborador.ToString() :
															sortColumnIndex == 2 && isDsTipoColaboradorSortable ? c.objTipoColaborador.DsTipoColaborador :
															sortColumnIndex == 3 && isNmColaboradorSortable ? c.NmColaborador.ToString() :
															sortColumnIndex == 4 && isDsEnderecoSortable ? c.DsEndereco.ToString() :
															sortColumnIndex == 5 && isNmCidadeSortable ? c.NmCidade.ToString() :
															sortColumnIndex == 6 && isNmUfSortable ? c.NmUf.ToString() :
															sortColumnIndex == 7 && isNrCnpjCpfSortable ? c.NrCnpjCpf.ToString() :
															sortColumnIndex == 8 && isNrTelefoneSortable ? c.NrTelefone.ToString() :
															"");
			var sortDirection = Request["sSortDir_0"]; // asc or desc
			if (sortDirection == "asc")
				filteredColaborador = filteredColaborador.OrderBy(orderingColaborador);
			else
				filteredColaborador = filteredColaborador.OrderByDescending(orderingColaborador);
			var result = from c in filteredColaborador select new[] { "", Convert.ToString(c.IdColaborador) , c.objTipoColaborador.DsTipoColaborador, c.NmColaborador, c.DsEndereco, c.NmCidade, c.NmUf, c.NrCnpjCpf, c.NrTelefone };
			return Json(new
			{
				sEcho = Params.sEcho,
				iTotalRecords = TotalRegistro,
				iTotalDisplayRecords = TotalRegistrosFiltrados,
				aaData = result
				}, JsonRequestBehavior.AllowGet);
		}
	}
}

