﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Transire.WebAplication.Models;
namespace Transire.WebAplication.Controllers
{
	public class ItemController : Controller
	{
		public ActionResult ItemCadastrar()
		{
			ViewBag.listDsProduto = new SelectList(new ProdutoModel().Consultar(), "IdProduto","DsProduto");
			return PartialView();
		}
		public ActionResult ItemAlterar()
		{
			ItemModel objItem = new ItemModel();
			objItem.IdItem = Int32.Parse(Request.QueryString["id"].ToString());
			List<ItemModel> listItem =  objItem.Consultar();
			ViewBag.listDsProduto = new SelectList(new ProdutoModel().Consultar(), "IdProduto","DsProduto", listItem[0].objProduto.IdProduto);
			ViewBag.txtQtPedido = listItem[0].QtPedido.ToString();
			ViewBag.txtVlPedido = listItem[0].VlPedido.ToString();
			ViewBag.IdItem = listItem[0].IdItem.ToString();
			return PartialView();
		}
		[HttpPost]
		public void ItemSalvar()
		{
			ItemModel objItem = new ItemModel();
			objItem.objProduto.IdProduto = Int32.Parse(Request["cboDsProduto"].ToString());
			objItem.QtPedido = decimal.Parse(Request["txtQtPedido"].ToString().Replace(".", ","));
			objItem.VlPedido = decimal.Parse(Request["txtVlPedido"].ToString().Replace(".", ","));
			string _response = objItem.Inserir();
			if (_response.Split('|')[0].Equals("sucesso"))
			{
			}
			else
			{
			}
			Response.Write(_response);
		}
		[HttpPost]
		public void ItemAtualizar()
		{
			ItemModel objItem = new ItemModel();
			objItem.objProduto.IdProduto = Int32.Parse(Request["cboDsProduto"].ToString());
			objItem.QtPedido = decimal.Parse(Request["txtQtPedido"].ToString().Replace(".", ","));
			objItem.VlPedido = decimal.Parse(Request["txtVlPedido"].ToString().Replace(".", ","));
			objItem.IdItem = Int32.Parse(Request["IdItem"].ToString());
			Response.Write(objItem.Alterar());
		}
		[HttpGet]
		public void ItemExcluir()
		{
			ItemModel objItem = new ItemModel();
			objItem.objProduto.IdProduto =  0;
			objItem.QtPedido = 0;
			objItem.VlPedido = 0;
			objItem.IdItem = 0;//Int32.Parse(Request.QueryString["id"].ToString());
			Response.Write(objItem.Excluir());
		}
		public ActionResult ItemListar()
		{
			return PartialView();
		}
		public ActionResult ExibirDataTable(JQueryDataTablesParamViewModel Params)
		{
			ItemModel objItem = new ItemModel();
			objItem.objProduto.IdProduto =  0;
			objItem.QtPedido = 0;
			objItem.VlPedido = 0;
			objItem.IdItem = 0;//Int32.Parse(Request.QueryString["id"].ToString());
			int ChaveDados = 0;
			int TotalRegistro = 0;
			int TotalRegistrosFiltrados = 0;//Convert.ToInt32(Request.Params["total"]);
			IEnumerable<ItemModel> filteredItem = objItem.Exibir(ChaveDados, Params, out TotalRegistro, out TotalRegistrosFiltrados);
			var isIdentificadorSortable = Convert.ToBoolean(Request["bSortable_1"]);
			var isDsProdutoSortable = Convert.ToBoolean(Request["bSortable_2"]);
			var isQtPedidoSortable = Convert.ToBoolean(Request["bSortable_3"]);
			var isVlPedidoSortable = Convert.ToBoolean(Request["bSortable_4"]);
			var sortColumnIndex = Convert.ToInt32(Request["iSortCol_0"]);
			Func<ItemModel, string> orderingItem = (c => sortColumnIndex == 1 && isIdentificadorSortable ? c.IdItem.ToString() :
															sortColumnIndex == 2 && isDsProdutoSortable ? c.objProduto.DsProduto :
															sortColumnIndex == 3 && isQtPedidoSortable ? c.QtPedido.ToString() :
															sortColumnIndex == 4 && isVlPedidoSortable ? c.VlPedido.ToString() :
															"");
			var sortDirection = Request["sSortDir_0"]; // asc or desc
			if (sortDirection == "asc")
				filteredItem = filteredItem.OrderBy(orderingItem);
			else
				filteredItem = filteredItem.OrderByDescending(orderingItem);
			var result = from c in filteredItem select new[] { "", Convert.ToString(c.IdItem) , c.objProduto.DsProduto, Convert.ToString(c.QtPedido), Convert.ToString(c.VlPedido) };
			return Json(new
			{
				sEcho = Params.sEcho,
				iTotalRecords = TotalRegistro,
				iTotalDisplayRecords = TotalRegistrosFiltrados,
				aaData = result
				}, JsonRequestBehavior.AllowGet);
		}
	}
}

