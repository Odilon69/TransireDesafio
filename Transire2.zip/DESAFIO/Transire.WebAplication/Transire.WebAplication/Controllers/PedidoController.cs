﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Transire.WebAplication.Models;
namespace Transire.WebAplication.Controllers
{
	public class PedidoController : Controller
	{
		public ActionResult PedidoCadastrar()
		{
			ViewBag.listNmColaborador = new SelectList(new ColaboradorModel().Consultar(), "IdColaborador","NmColaborador");
			return PartialView();
		}
		public ActionResult PedidoAlterar()
		{
			PedidoModel objPedido = new PedidoModel();
			objPedido.IdPedido = Int32.Parse(Request.QueryString["id"].ToString());
			List<PedidoModel> listPedido =  objPedido.Consultar();
			ViewBag.listNmColaborador = new SelectList(new ColaboradorModel().Consultar(), "IdColaborador","NmColaborador", listPedido[0].objColaborador.IdColaborador);
			ViewBag.txtTPedido = listPedido[0].TPedido.ToString();
			ViewBag.IdPedido = listPedido[0].IdPedido.ToString();
			return PartialView();
		}
		[HttpPost]
		public void PedidoSalvar()
		{
			PedidoModel objPedido = new PedidoModel();
			objPedido.objColaborador.IdColaborador = Int32.Parse(Request["cboNmColaborador"].ToString());//IdVendedor
			objPedido.TPedido = DateTime.Parse(Request["txtTPedido"].ToString());
			string _response = objPedido.Inserir();
			if (_response.Split('|')[0].Equals("sucesso"))
			{
			}
			else
			{
			}
			Response.Write(_response);
		}
		[HttpPost]
		public void PedidoAtualizar()
		{
			PedidoModel objPedido = new PedidoModel();
			objPedido.objColaborador.IdColaborador = Int32.Parse(Request["cboNmColaborador"].ToString());//IdVendedor
			objPedido.TPedido = DateTime.Parse(Request["txtTPedido"].ToString());
			objPedido.IdPedido = Int32.Parse(Request["IdPedido"].ToString());
			Response.Write(objPedido.Alterar());
		}
		[HttpGet]
		public void PedidoExcluir()
		{
			PedidoModel objPedido = new PedidoModel();
			objPedido.objColaborador.IdColaborador =  0;//IdVendedor
			objPedido.TPedido = DateTime.Parse("01/01/9999");
			objPedido.IdPedido = 0;//Int32.Parse(Request.QueryString["id"].ToString());
			Response.Write(objPedido.Excluir());
		}
		public ActionResult PedidoListar()
		{
			return PartialView();
		}
		public ActionResult ExibirDataTable(JQueryDataTablesParamViewModel Params)
		{
			PedidoModel objPedido = new PedidoModel();
			objPedido.objColaborador.IdColaborador =  0;//IdVendedor
			objPedido.TPedido = DateTime.Parse("01/01/9999");
			objPedido.IdPedido = 0;//Int32.Parse(Request.QueryString["id"].ToString());
			int ChaveDados = 0;
			int TotalRegistro = 0;
			int TotalRegistrosFiltrados = 0;//Convert.ToInt32(Request.Params["total"]);
			IEnumerable<PedidoModel> filteredPedido = objPedido.Exibir(ChaveDados, Params, out TotalRegistro, out TotalRegistrosFiltrados);
			var isIdentificadorSortable = Convert.ToBoolean(Request["bSortable_1"]);
			var isNmColaboradorSortable = Convert.ToBoolean(Request["bSortable_2"]);
			var isTPedidoSortable = Convert.ToBoolean(Request["bSortable_3"]);
			var sortColumnIndex = Convert.ToInt32(Request["iSortCol_0"]);
			Func<PedidoModel, string> orderingPedido = (c => sortColumnIndex == 1 && isIdentificadorSortable ? c.IdPedido.ToString() :
															sortColumnIndex == 2 && isNmColaboradorSortable ? c.objColaborador.NmColaborador :
															sortColumnIndex == 3 && isTPedidoSortable ? c.TPedido.ToString() :
															"");
			var sortDirection = Request["sSortDir_0"]; // asc or desc
			if (sortDirection == "asc")
				filteredPedido = filteredPedido.OrderBy(orderingPedido);
			else
				filteredPedido = filteredPedido.OrderByDescending(orderingPedido);
			var result = from c in filteredPedido select new[] { "", Convert.ToString(c.IdPedido) , c.objColaborador.NmColaborador, Convert.ToString(c.TPedido) };
			return Json(new
			{
				sEcho = Params.sEcho,
				iTotalRecords = TotalRegistro,
				iTotalDisplayRecords = TotalRegistrosFiltrados,
				aaData = result
				}, JsonRequestBehavior.AllowGet);
		}
	}
}

