﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Transire.WebAplication.Models;
namespace Transire.WebAplication.Controllers
{
	public class TipoProdutoController : Controller
	{
		public ActionResult TipoProdutoCadastrar()
		{
						return PartialView();
		}
		public ActionResult TipoProdutoAlterar()
		{
			TipoProdutoModel objTipoProduto = new TipoProdutoModel();
			objTipoProduto.IdTipoProduto = Int32.Parse(Request.QueryString["id"].ToString());
			List<TipoProdutoModel> listTipoProduto =  objTipoProduto.Consultar();
						ViewBag.txtDsTipoProduto = listTipoProduto[0].DsTipoProduto.ToString();
			ViewBag.IdTipoProduto = listTipoProduto[0].IdTipoProduto.ToString();
			return PartialView();
		}
		[HttpPost]
		public void TipoProdutoSalvar()
		{
			TipoProdutoModel objTipoProduto = new TipoProdutoModel();
			objTipoProduto.DsTipoProduto = Request["txtDsTipoProduto"].ToString();
			string _response = objTipoProduto.Inserir();
			if (_response.Split('|')[0].Equals("sucesso"))
			{
			}
			else
			{
			}
			Response.Write(_response);
		}
		[HttpPost]
		public void TipoProdutoAtualizar()
		{
			TipoProdutoModel objTipoProduto = new TipoProdutoModel();
						objTipoProduto.DsTipoProduto = Request["txtDsTipoProduto"].ToString();
			objTipoProduto.IdTipoProduto = Int32.Parse(Request["IdTipoProduto"].ToString());
			Response.Write(objTipoProduto.Alterar());
		}
		[HttpGet]
		public void TipoProdutoExcluir()
		{
			TipoProdutoModel objTipoProduto = new TipoProdutoModel();
			objTipoProduto.DsTipoProduto = "";
			objTipoProduto.IdTipoProduto = 0;//Int32.Parse(Request.QueryString["id"].ToString());
			Response.Write(objTipoProduto.Excluir());
		}
		public ActionResult TipoProdutoListar()
		{
			return PartialView();
		}
		public ActionResult ExibirDataTable(JQueryDataTablesParamViewModel Params)
		{
			TipoProdutoModel objTipoProduto = new TipoProdutoModel();
			objTipoProduto.DsTipoProduto = "";
			objTipoProduto.IdTipoProduto = 0;//Int32.Parse(Request.QueryString["id"].ToString());
			int ChaveDados = 0;
			int TotalRegistro = 0;
			int TotalRegistrosFiltrados = 0;//Convert.ToInt32(Request.Params["total"]);
			IEnumerable<TipoProdutoModel> filteredTipoProduto = objTipoProduto.Exibir(ChaveDados, Params, out TotalRegistro, out TotalRegistrosFiltrados);
			var isIdentificadorSortable = Convert.ToBoolean(Request["bSortable_1"]);
			var isDsTipoProdutoSortable = Convert.ToBoolean(Request["bSortable_2"]);
			var sortColumnIndex = Convert.ToInt32(Request["iSortCol_0"]);
			Func<TipoProdutoModel, string> orderingTipoProduto = (c => sortColumnIndex == 1 && isIdentificadorSortable ? c.IdTipoProduto.ToString() :
															           sortColumnIndex == 2 && isDsTipoProdutoSortable ? c.DsTipoProduto.ToString() :
															     "");
			var sortDirection = Request["sSortDir_0"]; // asc or desc

			if (sortDirection == "asc")
				filteredTipoProduto = filteredTipoProduto.OrderBy(orderingTipoProduto);
			else
				filteredTipoProduto = filteredTipoProduto.OrderByDescending(orderingTipoProduto);
			var result = from c in filteredTipoProduto select new[] { "", Convert.ToString(c.IdTipoProduto) , c.DsTipoProduto };
			return Json(new
			{
				sEcho = Params.sEcho,
				iTotalRecords = TotalRegistro,
				iTotalDisplayRecords = TotalRegistrosFiltrados,
				aaData = result
				}, JsonRequestBehavior.AllowGet);
		}
	}
}

