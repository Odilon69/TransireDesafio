﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Transire.WebAplication.Models;
namespace Transire.WebAplication.Controllers
{
    public class UnidadeMedidaController : Controller
    {
        public ActionResult UnidadeMedidaCadastrar()
        {
            return PartialView();
        }
        public ActionResult UnidadeMedidaAlterar()
        {
            UnidadeMedidaModel objUnidadeMedida = new UnidadeMedidaModel();
            objUnidadeMedida.IdUnidadeMedida = Int32.Parse(Request.QueryString["id"].ToString());
            List<UnidadeMedidaModel> listUnidadeMedida = objUnidadeMedida.Consultar();
            ViewBag.txtDsUnidadeMedida = listUnidadeMedida[0].DsUnidadeMedida.ToString();
            ViewBag.IdUnidadeMedida = listUnidadeMedida[0].IdUnidadeMedida.ToString();
            return PartialView();
        }
        [HttpPost]
        public void UnidadeMedidaSalvar()
        {
            UnidadeMedidaModel objUnidadeMedida = new UnidadeMedidaModel();
            objUnidadeMedida.DsUnidadeMedida = Request["txtDsUnidadeMedida"].ToString();
            string _response = objUnidadeMedida.Inserir();
            if (_response.Split('|')[0].Equals("sucesso"))
            {
            }
            else
            {
            }
            Response.Write(_response);
        }
        [HttpPost]
        public void UnidadeMedidaAtualizar()
        {
            UnidadeMedidaModel objUnidadeMedida = new UnidadeMedidaModel();
            objUnidadeMedida.DsUnidadeMedida = Request["txtDsUnidadeMedida"].ToString();
            objUnidadeMedida.IdUnidadeMedida = Int32.Parse(Request["IdUnidadeMedida"].ToString());
            Response.Write(objUnidadeMedida.Alterar());
        }
        [HttpGet]
        public void UnidadeMedidaExcluir()
        {
            UnidadeMedidaModel objUnidadeMedida = new UnidadeMedidaModel();
            objUnidadeMedida.DsUnidadeMedida = "";
            objUnidadeMedida.IdUnidadeMedida = 0;//Int32.Parse(Request.QueryString["id"].ToString());
            Response.Write(objUnidadeMedida.Excluir());
        }
        public ActionResult UnidadeMedidaListar()
        {
            return PartialView();
        }

        public ActionResult ExibirDataTable(JQueryDataTablesParamViewModel Params)
        {

            UnidadeMedidaModel objUnidadeMedida = new UnidadeMedidaModel();
            objUnidadeMedida.DsUnidadeMedida = "";
            objUnidadeMedida.IdUnidadeMedida = 0;//Int32.Parse(Request.QueryString["id"].ToString());
            int ChaveDados = 0;
            int TotalRegistro = 0;
            int TotalRegistrosFiltrados = 0;//Convert.ToInt32(Request.Params["total"]);
            IEnumerable<UnidadeMedidaModel> filteredUnidadeMedida = objUnidadeMedida.Exibir(ChaveDados, Params, out TotalRegistro, out TotalRegistrosFiltrados);
            var isIdentificadorSortable = Convert.ToBoolean(Request["bSortable_1"]);
            var isDsUnidadeMedidaSortable = Convert.ToBoolean(Request["bSortable_2"]);
            var sortColumnIndex = Convert.ToInt32(Request["iSortCol_0"]);
            Func<UnidadeMedidaModel, string> orderingUnidadeMedida = (c => sortColumnIndex == 1 && isIdentificadorSortable ? c.IdUnidadeMedida.ToString() :
                                                            sortColumnIndex == 2 && isDsUnidadeMedidaSortable ? c.DsUnidadeMedida.ToString() :
                                                            "");
            var sortDirection = Request["sSortDir_0"]; // asc or desc
            if (sortDirection == "asc")
                filteredUnidadeMedida = filteredUnidadeMedida.OrderBy(orderingUnidadeMedida);
            else
                filteredUnidadeMedida = filteredUnidadeMedida.OrderByDescending(orderingUnidadeMedida);
            var result = from c in filteredUnidadeMedida select new[] { "", Convert.ToString(c.IdUnidadeMedida), c.DsUnidadeMedida };
            return Json(new
            {
                sEcho = Params.sEcho,
                iTotalRecords = TotalRegistro,
                iTotalDisplayRecords = TotalRegistrosFiltrados,
                aaData = result
            }, JsonRequestBehavior.AllowGet);
        }
    }
}

