﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
namespace Transire.WebAplication.Models
{
	public class ColaboradorModel : ModelImpl<ColaboradorModel>
	{
		#region Propriedades
		public string NmColaborador { get; set; }
		public string DsEndereco { get; set; }
		public string NmCidade { get; set; }
		public string NmUf { get; set; }
		public string NrCnpjCpf { get; set; }
		public string NrTelefone { get; set; }
		public int IdColaborador { get; set; }
		#region Umparamuitos
		public TipoColaboradorModel objTipoColaborador = new TipoColaboradorModel();
		#endregion //Umparamuitos
		#region Muitosparamuitos
				#endregion //Muitosparamuitos
		#endregion //Propriedades
		#region Metodos
		public ColaboradorModel()
		{
			this.NmColaborador = "";
			this.DsEndereco = "";
			this.NmCidade = "";
			this.NmUf = "";
			this.NrCnpjCpf = "";
			this.NrTelefone = "";
			this.IdColaborador = 0;
			this.objTipoColaborador.IdTipoColaborador = 0;
		}
		public override string Inserir()
		{
			return this.Persistir(1);
		}
		public override string Alterar()
		{
			return this.Persistir(2);
		}
		public override string Excluir()
		{
			return this.Persistir(3);
		}
		public override string Persistir(int Oper)
		{
			this.conn.Conectar();
			this.conn.Parametros.Clear();
			this.conn.SetarSP("SPE_T006_COLABORADOR_IAD");
			this.conn.AdicionarParametro("IdOperacao",Oper, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("IdUsuarioSys", this._IdColaborador, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("IdTipoColaborador", this.objTipoColaborador.IdTipoColaborador, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("NmColaborador", this.NmColaborador.ToUpper(), System.Data.SqlDbType.VarChar);
			this.conn.AdicionarParametro("DsEndereco", this.DsEndereco.ToUpper(), System.Data.SqlDbType.VarChar);
			this.conn.AdicionarParametro("NmCidade", this.NmCidade.ToUpper(), System.Data.SqlDbType.VarChar);
			this.conn.AdicionarParametro("NmUf", this.NmUf.ToUpper(), System.Data.SqlDbType.VarChar);
			this.conn.AdicionarParametro("NrCnpjCpf", this.NrCnpjCpf.ToUpper(), System.Data.SqlDbType.VarChar);
			this.conn.AdicionarParametro("NrTelefone", this.NrTelefone.ToUpper(), System.Data.SqlDbType.VarChar);
			this.conn.AdicionarParametro("IdColaborador", this.IdColaborador, System.Data.SqlDbType.Int);
			return this.Execute();
		}
		public override List<ColaboradorModel> Consultar()
		{
			this.conn.Conectar();
			this.conn.Parametros.Clear();
			this.conn.SetarSP("SPE_T006_COLABORADOR_FND");
			this.conn.AdicionarParametro("ChaveDados", 0, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtInicio", 0, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtRegistros", 0, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("StringSearch", "", System.Data.SqlDbType.VarChar);
			this.conn.AdicionarParametro("IdColaborador", this.IdColaborador, System.Data.SqlDbType.Int);
			List<ColaboradorModel> resultado = new List<ColaboradorModel>();
			try
			{
				SqlDataReader reader = (SqlDataReader)conn.Executar();
				while (reader.Read())
				{
					ColaboradorModel objColaborador = new ColaboradorModel();
					objColaborador.objTipoColaborador.IdTipoColaborador = Int32.Parse(reader["T007ID_TIPO_COLABORADOR"].ToString());
					objColaborador.NmColaborador = reader["T006NM_COLABORADOR"].ToString();
					objColaborador.DsEndereco = reader["T006DS_ENDERECO"].ToString();
					objColaborador.NmCidade = reader["T006NM_CIDADE"].ToString();
					objColaborador.NmUf = reader["T006NM_UF"].ToString();
					objColaborador.NrCnpjCpf = reader["T006NR_CNPJ_CPF"].ToString();
					objColaborador.NrTelefone = reader["T006NR_TELEFONE"].ToString();
					objColaborador.IdColaborador = Int32.Parse(reader["T006ID_COLABORADOR"].ToString());
					resultado.Add(objColaborador);
				}
				conn.Desconectar();
				return resultado;
			}
			catch (SqlException)
			{
				return resultado;
			}
		}
		public override List<ColaboradorModel> Exibir(int ChaveDados, JQueryDataTablesParamViewModel Params, out int TotalRegistro, out int TotalRegistrosFiltrados)
		{
			TotalRegistro = 0;
			TotalRegistrosFiltrados = 0;
			this.conn.Conectar();
			this.conn.Parametros.Clear();
			this.conn.SetarSP("SPE_T006_COLABORADOR_FND");
			this.conn.AdicionarParametro("ChaveDados", ChaveDados, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtInicio", Params.iDisplayStart, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtRegistros", Params.iDisplayLength, System.Data.SqlDbType.Int);
			if (!string.IsNullOrEmpty(Params.sSearch))
			{
				this.conn.AdicionarParametro("StringSearch", Params.sSearch.ToLower(), System.Data.SqlDbType.VarChar);
			}
			else
			{
				this.conn.AdicionarParametro("StringSearch", "", System.Data.SqlDbType.VarChar);
			}
						List<ColaboradorModel> resultado = new List<ColaboradorModel>();
			try
			{
				SqlDataReader reader = (SqlDataReader)conn.Executar();
				while (reader.Read())
				{
					TotalRegistro = Convert.ToInt32(reader["Total"]);
					TotalRegistrosFiltrados = Convert.ToInt32(reader["TotalFiltrado"]);
					ColaboradorModel objColaborador = new ColaboradorModel();
					objColaborador.objTipoColaborador.IdTipoColaborador = Int32.Parse(reader["T007ID_TIPO_COLABORADOR"].ToString());
					objColaborador.objTipoColaborador.DsTipoColaborador = reader["T007DS_TIPO_COLABORADOR"].ToString();
					objColaborador.NmColaborador = reader["T006NM_COLABORADOR"].ToString();
					objColaborador.DsEndereco = reader["T006DS_ENDERECO"].ToString();
					objColaborador.NmCidade = reader["T006NM_CIDADE"].ToString();
					objColaborador.NmUf = reader["T006NM_UF"].ToString();
					objColaborador.NrCnpjCpf = reader["T006NR_CNPJ_CPF"].ToString();
					objColaborador.NrTelefone = reader["T006NR_TELEFONE"].ToString();
					objColaborador.IdColaborador = Int32.Parse(reader["T006ID_COLABORADOR"].ToString());
					resultado.Add(objColaborador);
				}
				conn.Desconectar();
				return resultado;
			}
			catch (SqlException)
			{
				return resultado;
			}
		}
		#endregion
	}
}

