﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
namespace Transire.WebAplication.Models
{
	public class ProdutoModel : ModelImpl<ProdutoModel>
	{
		#region Propriedades
		public string DsProduto { get; set; }
		public decimal VlPrecoUnitario { get; set; }
		public decimal QtEstoque { get; set; }
		public DateTime DtCadastro { get; set; }
		public int IdProduto { get; set; }
		#region Umparamuitos
		public ColaboradorModel objColaborador = new ColaboradorModel();
		public StatusProdutoModel objStatusProduto = new StatusProdutoModel();
		public TipoProdutoModel objTipoProduto = new TipoProdutoModel();
		public UnidadeMedidaModel objUnidadeMedida = new UnidadeMedidaModel();
		#endregion //Umparamuitos
		#region Muitosparamuitos
				#endregion //Muitosparamuitos
		#endregion //Propriedades
		#region Metodos
		public ProdutoModel()
		{
			this.DsProduto = "";
			this.VlPrecoUnitario = 0;
			this.QtEstoque = 0;
			this.DtCadastro = DateTime.Parse("01/01/9999");
			this.IdProduto = 0;
			this.objColaborador.IdColaborador = 0;//IdFornecedor
			this.objStatusProduto.IdStatusProduto = 0;
			this.objTipoProduto.IdTipoProduto = 0;
			this.objUnidadeMedida.IdUnidadeMedida = 0;
		}
		public override string Inserir()
		{
			return this.Persistir(1);
		}
		public override string Alterar()
		{
			return this.Persistir(2);
		}
		public override string Excluir()
		{
			return this.Persistir(3);
		}
		public override string Persistir(int Oper)
		{
			this.conn.Conectar();
			this.conn.Parametros.Clear();
			this.conn.SetarSP("SPE_T002_PRODUTO_IAD");
			this.conn.AdicionarParametro("IdOperacao",Oper, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("IdUsuarioSys", this._IdColaborador, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("IdFornecedor", this.objColaborador.IdColaborador, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("IdStatusProduto", this.objStatusProduto.IdStatusProduto, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("IdTipoProduto", this.objTipoProduto.IdTipoProduto, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("IdUnidadeMedida", this.objUnidadeMedida.IdUnidadeMedida, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("DsProduto", this.DsProduto.ToUpper(), System.Data.SqlDbType.VarChar);
			this.conn.AdicionarParametro("VlPrecoUnitario", this.VlPrecoUnitario, System.Data.SqlDbType.Decimal);
			this.conn.AdicionarParametro("QtEstoque", this.QtEstoque, System.Data.SqlDbType.Decimal);
			this.conn.AdicionarParametro("DtCadastro", this.DtCadastro, System.Data.SqlDbType.DateTime);
			this.conn.AdicionarParametro("IdProduto", this.IdProduto, System.Data.SqlDbType.Int);
			return this.Execute();
		}
		public override List<ProdutoModel> Consultar()
		{
			this.conn.Conectar();
			this.conn.Parametros.Clear();
			this.conn.SetarSP("SPE_T002_PRODUTO_FND");
			this.conn.AdicionarParametro("ChaveDados", 0, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtInicio", 0, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtRegistros", 0, System.Data.SqlDbType.Int);
				this.conn.AdicionarParametro("StringSearch", "", System.Data.SqlDbType.VarChar);
				this.conn.AdicionarParametro("IdProduto", this.IdProduto, System.Data.SqlDbType.Int);
			List<ProdutoModel> resultado = new List<ProdutoModel>();
			try
			{
				SqlDataReader reader = (SqlDataReader)conn.Executar();
				while (reader.Read())
				{
					ProdutoModel objProduto = new ProdutoModel();
					objProduto.objColaborador.IdColaborador = Int32.Parse(reader["T006ID_FORNECEDOR"].ToString());
					objProduto.objStatusProduto.IdStatusProduto = Int32.Parse(reader["T005ID_STATUS_PRODUTO"].ToString());
					objProduto.objTipoProduto.IdTipoProduto = Int32.Parse(reader["T003ID_TIPO_PRODUTO"].ToString());
					objProduto.objUnidadeMedida.IdUnidadeMedida = Int32.Parse(reader["T011ID_UNIDADE_MEDIDA"].ToString());
					objProduto.DsProduto = reader["T002DS_PRODUTO"].ToString();
					objProduto.VlPrecoUnitario = decimal.Parse(reader["T002VL_PRECO_UNITARIO"].ToString());
					objProduto.QtEstoque = decimal.Parse(reader["T002QT_ESTOQUE"].ToString());
					objProduto.DtCadastro = DateTime.Parse(reader["T002DT_CADASTRO"].ToString());
					objProduto.IdProduto = Int32.Parse(reader["T002ID_PRODUTO"].ToString());
					resultado.Add(objProduto);
				}
				conn.Desconectar();
				return resultado;
			}
			catch (SqlException)
			{
				return resultado;
			}
		}
		public override List<ProdutoModel> Exibir(int ChaveDados, JQueryDataTablesParamViewModel Params, out int TotalRegistro, out int TotalRegistrosFiltrados)
		{
			TotalRegistro = 0;
			TotalRegistrosFiltrados = 0;
			this.conn.Conectar();
			this.conn.Parametros.Clear();
			this.conn.SetarSP("SPE_T002_PRODUTO_FND");
			this.conn.AdicionarParametro("ChaveDados", ChaveDados, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtInicio", Params.iDisplayStart, System.Data.SqlDbType.Int);
			this.conn.AdicionarParametro("QtRegistros", Params.iDisplayLength, System.Data.SqlDbType.Int);
			if (!string.IsNullOrEmpty(Params.sSearch))
			{
				this.conn.AdicionarParametro("StringSearch", Params.sSearch.ToLower(), System.Data.SqlDbType.VarChar);
			}
			else
			{
				this.conn.AdicionarParametro("StringSearch", "", System.Data.SqlDbType.VarChar);
			}
			//this.conn.AdicionarParametro("DtCadastro", this.DtCadastro, System.Data.SqlDbType.DateTime);
			List<ProdutoModel> resultado = new List<ProdutoModel>();
			try
			{
				SqlDataReader reader = (SqlDataReader)conn.Executar();
				while (reader.Read())
				{
					TotalRegistro = Convert.ToInt32(reader["Total"]);
					TotalRegistrosFiltrados = Convert.ToInt32(reader["TotalFiltrado"]);
					ProdutoModel objProduto = new ProdutoModel();
					objProduto.objColaborador.IdColaborador = Int32.Parse(reader["T006ID_FORNECEDOR"].ToString());
					objProduto.objColaborador.NmColaborador = reader["T006NM_COLABORADOR"].ToString();
					objProduto.objStatusProduto.IdStatusProduto = Int32.Parse(reader["T005ID_STATUS_PRODUTO"].ToString());
					objProduto.objStatusProduto.DsStatusProduto = reader["T005DS_STATUS_PRODUTO"].ToString();
                    objProduto.objStatusProduto.FgClass = reader["T005FG_CLASS"].ToString();
					objProduto.objTipoProduto.IdTipoProduto = Int32.Parse(reader["T003ID_TIPO_PRODUTO"].ToString());
					objProduto.objTipoProduto.DsTipoProduto = reader["T003DS_TIPO_PRODUTO"].ToString();
					objProduto.objUnidadeMedida.IdUnidadeMedida = Int32.Parse(reader["T011ID_UNIDADE_MEDIDA"].ToString());
                    objProduto.objUnidadeMedida.DsUnidadeMedida = reader["T011DS_UNIDADE_MEDIDA"].ToString();
					objProduto.DsProduto = reader["T002DS_PRODUTO"].ToString();
					objProduto.VlPrecoUnitario = decimal.Parse(reader["T002VL_PRECO_UNITARIO"].ToString());
					objProduto.QtEstoque = decimal.Parse(reader["T002QT_ESTOQUE"].ToString());
					objProduto.DtCadastro = DateTime.Parse(reader["T002DT_CADASTRO"].ToString());
					objProduto.IdProduto = Int32.Parse(reader["T002ID_PRODUTO"].ToString());
					resultado.Add(objProduto);
				}
				conn.Desconectar();
				return resultado;
			}
			catch (SqlException)
			{
				return resultado;
			}
		}
		#endregion
	}
}

