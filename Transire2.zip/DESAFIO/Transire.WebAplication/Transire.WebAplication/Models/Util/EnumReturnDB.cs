﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Transire.WebAplication.Models.Util
{
    public enum EnumReturnDB
    {
        sucesso,
        outros,
        erro
    }
}