﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Transire.WebAplication.Models
{
    public interface IModel<T>
    {
        /// <summary>
        /// Teste
        /// </summary>
        /// <returns>void</returns>
        string Inserir();
        string Alterar();
        string Excluir();
        List<T> Consultar();
        List<T> Exibir(int ChaveDados, JQueryDataTablesParamViewModel Params, out int TotalRegistro, out int TotalRegistrosFiltrados);
        //FlexgridComMVC.Helpers.Flexigrid Exibir(FlexgridComMVC.Helpers.Flexigrid objFlex);
    }
}