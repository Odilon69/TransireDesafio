﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Transire.WebAplication.Models
{
    public class JsonModel
    {
        public string RowJson { get; set; }
        public JsonModel()
        {
            this.RowJson = "";
        }


    }
}