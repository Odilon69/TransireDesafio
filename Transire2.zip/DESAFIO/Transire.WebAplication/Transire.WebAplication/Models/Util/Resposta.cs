﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Transire.WebAplication.Models
{
    public class Resposta
    {
        public string CdResposta { get; set; }
        public string DsResposta { get; set; }

        public Resposta()
        {
            this.CdResposta = "";
            this.DsResposta = "";
        }

    }
}