﻿$(document).ready(function () {
    var oTable = $('#datatable').dataTable({
        "lengthMenu": [[8, 25, 50, -1], [8, 25, 50, "Todos"]],
        "bServerSide": true,
        "sAjaxSource": "Produto/ExibirDataTable",
        "bProcessing": true,
        "error": function (xhr, error, thrown) {
            Fn_AjaxGet('/Acesso/Acessar/st', 'definicaoArquitetura', 'Carregando...');
        },
        "aoColumns": [
                {
                    "sName": "Editar",
                    "bSearchable": false,
                    "bSortable": false,
                    data: null, render: function (data, type, row) { return '<p data-placement="top" data-toggle="tooltip" title="Editar"><button class="btn btn-default btn-xs btn-flat" data-title="Editar" onclick="fn_editaItem(' + data[1] + ');return false;"><span class="glyphicon glyphicon-pencil"></span></button></p>'; }
                },
                {
					"sName": "ID"
                },
				{
					"sName": "NMCOLABORADOR"
				},
				{
				    "sName": "DSSTATUSPRODUTO",
				    data: null, render: function (data, type, row) { return '<span class=\"' + data[10] + '\">' + data[3] + '</span>'; }
				},
				{
					"sName": "DSTIPOPRODUTO"
				},
				{
					"sName": "DSUNIDADEMEDIDA"
				},
				{
					"sName": "DSPRODUTO"
				},
				{
					"sName": "VLPRECOUNITARIO"
				},
				{
					"sName": "QTESTOQUE"
				},
				{
					"sName": "DTCADASTRO"
				},
                {
					"sName": "Excluir",
					"bSearchable": false,
					"bSortable": false,
					data: null, render: function (data, type, row) { return '<p data-placement="top" data-toggle="tooltip" title="Excluir"><button class="btn btn-default btn-xs btn-flat" data-title="Excluir" data-href="fn_excluirItem(' + data[1] + ');return false;" data-toggle="modal" data-target="#delete-modal" ><span class="glyphicon glyphicon-trash"></span></button></p>'; }
                },
        ],
        "oLanguage": {
            "sProcessing": "Processando...",
            "sLengthMenu": "Mostrar _MENU_ registros",
            "sZeroRecords": "Não foram encontrados resultados",
            "sInfo": "Mostrando de _START_ até _END_ de _TOTAL_ registros",
            "sInfoEmpty": "Mostrando de 0 até 0 de 0 registros",
            "sInfoFiltered": "(filtrado de _MAX_ registros no total)",
            "sInfoPostFix": "",
            "sSearch": "Buscar:",
            "sUrl": "",
            "oPaginate": {
                "sFirst": "«« Primeiro",
                "sPrevious": "« Anterior",
                "sNext": "Seguinte »",
                "sLast": "Último »»",
                "iTotalRecords": 12,
                "iTotalDisplayRecords": 12
            }
        },
        responsive: {
            details: {
                display: $.fn.dataTable.Responsive.display.modal({
                    header: function (row) {
                        var data = row.data();
                        return 'Detalhes de ' + data[0] + ' ' + data[1];
                    }
                }),
                renderer: $.fn.dataTable.Responsive.renderer.tableAll({tableClass: 'table'})
            }
        },
    });
    $('#datatable tbody').on('dblclick', 'tr', function () {
        var aData = oTable.fnGetData(this);
        Fn_AjaxGet('/Produto/ProdutoAlterar?id=' + aData[1], 'definicaoArquitetura', 'Carregando...', '');
    });
    $('#delete-modal').on('show.bs.modal', function (e) {
        $(this).find('.btn-ok').attr('onclick', $(e.relatedTarget).data('href'));
        //$(this).dialog("close");
    });
});

