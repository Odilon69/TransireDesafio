﻿var path = "";
var path_app = "";
var pathArray = window.location.pathname.split('/');

path_app = window.location.pathname;

// Caso não seja local
if (window.location.hostname != 'localhost') {

    //path = window.location.protocol + '//' + window.location.hostname + '/' + "ms"
    path = window.location.protocol + '//' + window.location.hostname + '/' + pathArray[1];
    path_app = path;

}
/*
Configuração de divs para serem usadas no sistema
* @author
*  - Odilon Bentes Monteiro
* @Data Criacao
*  - 14/04/2018
*/
var configAlert = '';
configAlert = configAlert + '<input type="hidden" id="success" value="@TempData["success"]" />';
configAlert = configAlert + '<input type="hidden" id="info" value="@TempData["info"]" />';
configAlert = configAlert + '<input type="hidden" id="warning" value="@TempData["warning"]" />';
configAlert = configAlert + '<input type="hidden" id="error" value="@TempData["error"]" />';

configAlert = configAlert + '<div id="dvProcessando" style="display: none; position: absolute; z-index: 6999;">';
configAlert = configAlert + '    <div class="ui-widget-overlay" style="border-top-width: 0px; bottom: 0px; margin-bottom: 14px; margin-left: -5px; right: 8px; margin-top: -17px;"></div>';
configAlert = configAlert + '    <div id="dvProcessandoShadow" class="ui-widget-shadow ui-corner-all" style="width: 302px; height: 152px; position: fixed;"></div>';
configAlert = configAlert + '    <div id="dvConteudoProcessando" style="display: inline; position: fixed; width: 280px; height: 130px; padding: 10px;" class="ui-widget ui-widget-content ui-corner-all"></div>';
configAlert = configAlert + '</div>';
configAlert = configAlert + '<div id="dvProcessandoGet" style="display: none; position: absolute; z-index: 6999;">';
configAlert = configAlert + '    <div class="ui-widget-overlay" style="border-top-width: 0px; bottom: 0px; margin-bottom: 14px; margin-left: -5px; right: 8px; margin-top: -17px;"></div>';
configAlert = configAlert + '    <div id="dvProcessandoShadowGet" class="ui-widget-shadow ui-corner-all" style="width: 302px; height: 152px; position: fixed;"></div>';
configAlert = configAlert + '    <div id="dvConteudoProcessandoGet" style="display: inline; position: fixed; width: 280px; height: 130px; padding: 10px;" class="ui-widget ui-widget-content ui-corner-all"></div>';
configAlert = configAlert + '</div>';

document.write(configAlert);


function atualizarDashboard() {
    $.ajax(
    {
        type: 'GET',
        url: '/Home/DashBoard',
        dataType: 'html',
        cache: false,
        async: true,
        success: function (data) {
            $('#definicaoArquitetura').html(data);
        }
    });
}
//--------------------------------------------------------------------------------
function fn_ajaxPost(url, frm, mensagem, returnData) {

    //clearInterval(TimeDash);

    var _return = '';
    toastr.options = {
        "positionClass": "toast-bottom-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "2000",
    };

    $.ajax({
        url: url,
        dataType: "html",
        type: "POST",
        data: $('#' + frm).serialize(),
        beforeSend: function () {
            fn_processando(mensagem);
        },
        complete: function () {

            fn_processando_fechar();
        },
        success: function (data, textStatus) {
            data = fn_Trim(data);
            var msg = data.split("|");
            _return += msg[0];
            if (msg[0] != 'session') {
                if (!returnData) {
                    if (msg[0] == 'sucesso') {
                        toastr.success('<strong>' + msg[0] + '! </strong>' + msg[1]);
                        //Limpa o form
                        $('#' + frm).get(0).reset();
                    } else if (msg[0] == 'erro') {
                        toastr.error('<strong>' + msg[0] + '! </strong>' + msg[1]);
                    } else if (msg[0] == 'sucessoNaoLimpa') {
                        toastr.success('<strong>' + msg[0] + '! </strong>' + msg[1]);
                    } else if (msg[0] == 'outros') {
                        toastr.warning('<strong>' + msg[0] + '! </strong>' + msg[1]);
                    }
                } else {
                    if (msg[0] == 'sucesso') {
                        toastr.success('<strong>' + msg[0] + '! </strong>' + msg[1]);
                        //$('#' + frm).get(0).reset();
                    } else if (msg[0] == 'erro') {
                        toastr.error('<strong>' + msg[0] + '! </strong>' + msg[1]);
                    } else if (msg[0] == 'sucessoNaoLimpa') {
                        toastr.success('<strong>' + msg[0] + '! </strong>' + msg[1]);
                    } else if (msg[0] == 'outros') {
                        toastr.warning('<strong>' + msg[0] + '! </strong>' + msg[1]);
                    }
                    returnData.call(this, msg);
                }
            }
            else {
                //Direciona para a pagina principal
                window.location = path + "/Acesso/Acessar/st";
            }
        },
        error: function (xhr, er) {
            //Dialogo para a msg de sucesso
            toastr.error('<strong>Ops!!</strong> Pagina n&atilde;o encontrada, contate o Administrador!');
            //fn_processando_fechar();
            //fn_msgDialogoErro('Pagina n&atilde;o encontrada, contate o Administrador!');
        }
    });
    return _return;
}

function Fn_AjaxGet(Url, Div, mensagem, returnData) {
    $.ajax(
    {
        type: "GET",
        url: Url,
        dataType: "html",
        cache: false,
        async: true,
        beforeSend: function () {
            fn_processandoGet(mensagem);
            //toastr.warning('<strong>Aguarde! </strong> Processando...');
        },
        complete: function () {
            fn_processando_fecharGet();
            //toastr.warning('<strong>Sucesso! </strong> Bom trabalho.');
        },
        success: function (data) {
            toastr.options = {
                "positionClass": "toast-bottom-right",
                "preventDuplicates": false,
                "onclick": null,
                "showDuration": "300",
                "hideDuration": "1000",
                "timeOut": "2000",
            };

            if (data != "session") {
                if (Div != '') {
                    $('#' + Div).html(data);
                }
            }
            else {
                Fn_AjaxGet(path + '/Acesso/Acessar/st', 'definicaoArquitetura', 'Carregando!', '');
                toastr.warning('<strong>Ops!!</strong> Sessão expirada. Favor logar novamente!');
                exit;
            }
            data = fn_Trim(data);
            var msg = data.split("|");
            if (!returnData) {
                if (msg[0] == 'sucesso') {
                    toastr.success('<strong>' + msg[0] + '! </strong>' + msg[1]);
                } else if (msg[0] == 'erro') {
                    toastr.error('<strong>' + msg[0] + '! </strong>' + msg[1]);
                } else if (msg[0] == 'sucessoNaoLimpa') {
                    toastr.success('<strong>' + msg[0] + '! </strong>' + msg[1]);
                } else if (msg[0] == 'outros') {
                    toastr.warning('<strong>' + msg[0] + '! </strong>' + msg[1]);
                }
            }
            else {
                if (msg[0] == 'sucesso') {
                    toastr.success('<strong>' + msg[0] + '! </strong>' + msg[1]);
                } else if (msg[0] == 'erro') {
                    toastr.error('<strong>' + msg[0] + '! </strong>' + msg[1]);
                } else if (msg[0] == 'sucessoNaoLimpa') {
                    toastr.success('<strong>' + msg[0] + '! </strong>' + msg[1]);
                } else if (msg[0] == 'outros') {
                    toastr.warning('<strong>' + msg[0] + '! </strong>' + msg[1]);
                }
                //returnData.call(this, msg);
            }
        },
        error: function (xhr, er) {
            toastr.error('<strong>Ops!!</strong> Pagina n&atilde;o encontrada, contate o Administrador!');
        }
    });
}

function fn_carregaMenu(caminhoMenu) {

    if (caminhoMenu != '') {
        Fn_AjaxGet(path + caminhoMenu, 'definicaoArquitetura', 'Carregando!', '');
    }
}

function fn_editaItem(id) {

    if (id != 0) {
        Fn_AjaxGet($("#urlEditar").val() + '?id=' + id, 'definicaoArquitetura', 'Carregando...', '');
    }
}

function fn_excluirItem(id) {

    if (id != 0) {
        Fn_AjaxGet($("#urlExcluir").val() + '?id=' + id, 'definicaoArquitetura', 'Carregando...', '');
    }
}

function fn_processando(mensagem) {

    var figuraProcessando = '<p style="text-align:center;font-size: 14px; font-weight: bold; color: #41a2b9;"><img src="' + path + '/Content/AppImg/processando.gif" border="0" align="absmiddle" />'
    document.getElementById('dvConteudoProcessando').innerHTML = '<br/><br/>' + figuraProcessando + ' <br>  ' + mensagem + '</p>';

    //armazena a largura e a altura da tela
    var maskHeight = $(document).height();
    var maskWidth = $(document).width();

    //aqui que faz a animação do explode
    //    $('#dvProcessando').css({
    //        'width': maskWidth,
    //        'height': maskHeight
    //    });
    //armazena a largura e a altura da janela
    var winH = $(window).height();
    var winW = $(window).width();

    $('#dvConteudoProcessando').css('top', winH / 2 - $('#dvConteudoProcessando').height() / 2);
    $('#dvConteudoProcessando').css('left', winW / 2 - $('#dvConteudoProcessando').width() / 2);

    $('#dvProcessandoShadow').css('top', winH / 2 - $('#dvConteudoProcessando').height() / 2);
    $('#dvProcessandoShadow').css('left', winW / 2 - $('#dvConteudoProcessando').width() / 2);

    $('body').css('overflow', 'hidden');
    $('#dvProcessando').fadeIn(0);

}

function fn_processandoGet(mensagem) {
    var figuraProcessando = '<p style="text-align:center;font-size: 14px; font-weight: bold; color: #41a2b9;"><img src="' + path + '/Content/AppImg/processando.gif" border="0" align="absmiddle" />'
    document.getElementById('dvConteudoProcessandoGet').innerHTML = '<br/><br/>' + figuraProcessando + ' <br>  ' + mensagem + '</p>';

    //armazena a largura e a altura da tela
    var maskHeight = $(document).height();
    var maskWidth = $(document).width();

    //aqui que faz a animação do explode
    //    $('#dvProcessandoGet').css({
    //        'width': maskWidth,
    //        'height': maskHeight
    //    });
    //armazena a largura e a altura da janela
    var winH = $(window).height();
    var winW = $(window).width();

    $('#dvConteudoProcessandoGet').css('top', winH / 2 - $('#dvConteudoProcessandoGet').height() / 2);
    $('#dvConteudoProcessandoGet').css('left', winW / 2 - $('#dvConteudoProcessandoGet').width() / 2);

    $('#dvProcessandoShadowGet').css('top', winH / 2 - $('#dvConteudoProcessandoGet').height() / 2);
    $('#dvProcessandoShadowGet').css('left', winW / 2 - $('#dvConteudoProcessandoGet').width() / 2);

    $('body').css('overflow', 'hidden');
    $('#dvProcessandoGet').fadeIn(0);

}

function fn_processando_fechar() {
    $('#dvProcessando').toggle("none", 0);

    setTimeout("$('body').css('overflow','visible');", 0);
}


function fn_processando_fecharGet() {
    $('#dvProcessandoGet').toggle("none", 0);

    setTimeout("$('body').css('overflow','visible');", 0);

}

function fn_Trim(txVariavel) {
    return txVariavel.replace(/^\s+|\s+$/g, "");
}

function fn_limpaFundo(input) {

    var aux = input.split("[");

    //se o nome for um array
    if (aux.length > 1) {
        //quebra pelo cochete
        input = input.split("[");
        //pega somente o nome
        input = input[0];
    }

    //id não existe no input
    if (document.getElementById(input) == null) {
        //sai da função
        return;
    }

    //verifica se é do tipo checkbox ou radio e se existe id
    if ($("input[type=checkbox]input[id=" + input + "]").length > 0 || $("input[type=radio]input[id=" + input + "]").length > 0) {
        //limpa o class
        $('#' + input).attr('class', '');
    }
    else if (document.getElementById(input).type == 'textarea')//verifica se é textarea
    {
        $('#' + input).attr('class', 'input');
    }
    else if (document.getElementById(input).type != 'file' && $('#' + input).attr('class') != 'file') {
        //coloca a classe padrão do input
        $('#' + input).attr('class', 'input');
    }

}

/**
* Método responsável por mudar o status do grid para Sim/Não.
* @author :Marcos Pessoa;
* @Data de Criação : 11/10/2012
* @access public
* @return void
*/
function fn_modificaStringStatusSN(nomeAbbr) {

    //faz o tratamento de excluir liberado e bloqueado
    $('.flexigrid .bDiv table td[abbr=' + nomeAbbr + '] div').each(function () {

        //pega o texto do grid
        var texto = $(this).text();
        if (texto == 'S') {
            //$(this).html('<font color="blue">SIM</font> ');
            $(this).html('<input name="A" type="checkbox" value="S" checked><br>');
            //$(this).html('<input name="A" type="checkbox" value="S" checked>A<input name="A" type="checkbox" value="N">B<br>');
        }
        else {
            //$(this).html('<font color="red">NÃO</font> ');
            $(this).html('<input name="A" type="checkbox" value="N"><br>');
        }

    });

}
function fn_limpa() {

    $('input:text,input:password,input[type=captcha], textarea').keydown(function () {
        fn_limpaFundo($(this).attr("id"));
    });

    $('select').change(function () {
        fn_limpaFundo($(this).attr("id"));
    });

    $('input').change(function () {
        fn_limpaFundo($(this).attr("name"));
    });

    $('.inputPesquisa').focus(function () {
        var id = $(this).attr("id");
        $('#' + id + 'P').removeClass();
        $('#' + id + 'P').addClass('fieldsetPesquisaFocus');
    });

    $('.inputPesquisa').blur(function () {
        var id = $(this).attr("id");
        $('#' + id + 'P').removeClass();
        $('#' + id + 'P').addClass('fieldsetPesquisa');
    });

    $('.inputPesquisaObrigatorio').focus(function () {
        if ($(this).val() == '') {
            var id = $(this).attr("id");
            $('#' + id + 'P').removeClass();
            $('#' + id + 'P').addClass('fieldsetPesquisaFocusObrigatorio');
        }
    });

    $('.inputPesquisaObrigatorio').blur(function () {
        if ($(this).val() == '') {
            var id = $(this).attr("id");
            $('#' + id + 'P').removeClass();
            $('#' + id + 'P').addClass('fieldsetPesquisaObrigatorio');
        }
    });

    $('.inputPesquisaObrigatorio,.inputPesquisa').keydown(function () {
        var id = $(this).attr("id");

        $('#' + id + 'P').removeClass();
        $('#' + id + 'P').addClass('fieldsetPesquisa');

        $('#' + id).removeClass();
        $('#' + id).addClass('inputPesquisa');
    });


    $('input:file').change(function () {
        $('.uploadDiv, .uploadDivObrigatorio').each(function () {
            if ($(this).attr('alt') == 'obrigatorio') {
                var div = $(this).find('div:first');
                var li = $(this).find('div ul');

                var quantidadeImagens = $(div).find('div').length;
                var quantidadeArquivos = $(li).find('li').length;

                if (quantidadeImagens == 0 && quantidadeArquivos == 0) {
                    $(this).removeClass();
                    $(this).addClass('uploadDivObrigatorio');
                }
                else {
                    $(this).removeClass();
                    $(this).addClass('uploadDiv');
                }
            }
        });
    });
}