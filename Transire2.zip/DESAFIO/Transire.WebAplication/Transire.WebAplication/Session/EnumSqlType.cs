﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;

namespace Transire.WebAplication.Util
{
    public static class EnumSqlType
    {

        public static SqlDbType SqlDbTypeEnum(string type)
        {

            //SqlDbType objSqlType;


            switch (type.ToLower()) {

                case "int" : {
                                 return SqlDbType.Int;
                };


                case "string":
                    {
                        return SqlDbType.VarChar;
                    };


                case "float":
                    {
                        return SqlDbType.Float;
                    };


                case "double":
                    {
                        return SqlDbType.Decimal;
                    };


                case "datetime":
                    {
                        return SqlDbType.DateTime;
                    };

                default:
                    {
                        return SqlDbType.Int;
                    }


            }


            


        }






    }
}